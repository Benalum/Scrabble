package Areas.StartingArea;

import Areas.MapBuilder.MapBuilder;
import MapHandlers.MapType;
import javafx.scene.layout.GridPane;

public class StartArea {
    public static class initializeStartArea {
        GridPane mapGrid = new GridPane();


        MapBuilder map = new MapBuilder(MapType.Starting_Area);


        // Create a function that will read in the map
    }
}
