package Areas.MapBuilder;


import Areas.ImageFinder.ImageFinder;
import MapHandlers.MapType;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class MapBuilder {
    public MapBuilder(MapType mapType) {
        if (mapType == MapType.Starting_Area) {
            String[][] map = readTextFile("Maps/StartingArea/StartingArea.txt");
        }else{
            System.out.println("Error no map found");
        }
    }

    private String[][] readTextFile(String locationOfFile){
        try (BufferedReader reader = new BufferedReader(new FileReader(locationOfFile))) {
            String size = reader.readLine();
            String[] sizes = size.split("x");
            int row = Integer.parseInt(sizes[0]);
            int col = Integer.parseInt(sizes[1]);
            int index = 0;
            String line;
            String[][] map = new String[row][col];
            while ((line = reader.readLine()) != null) {
                String[] lineSections = line.split(",");
                for(int i = 0; i < row; i++){
                    map[index][i] = lineSections[i];
                }
                index++;
            }
            return map;

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Can not Map, Map issue 12357");
        return null;
    }
    private void buildMap(String[][] mapText, GridPane gridPane) {

        for (int i = 0; i < mapText.length; i++) {
            for (int j = 0; j < mapText[i].length; j++) {
                Pane square = new Pane();
                String line = mapText[i][j];
                String[] lineSections = line.split("-");

                for (String section : lineSections) {
                    ImageView imageView = ImageFinder.findImage(section);
                    if (imageView != null) {
                        square.getChildren().add(imageView);
                    }
                }
                // Add the square (Pane) to the GridPane
                gridPane.add(square, j, i);
            }
        }
    }
}