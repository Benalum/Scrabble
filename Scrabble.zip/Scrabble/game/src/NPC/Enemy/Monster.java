package NPC.Enemy;

public class Monster {
    private String name;
    private int health;
    private int attackPower;

    // Constructor, getters, and setters
}
