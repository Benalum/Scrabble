package MapHandlers;

import GUI.InformationGUI.InformationGUI;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import Player.Player;
import javafx.scene.image.ImageView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MapManager {
    private Player player;
    private int viewportRows = 30;  // Number of rows visible in the viewport
    private int viewportCols = 30;  // Number of columns visible in the viewport
    private String[][] mapData;  // Store the entire map data as strings

    // Cache images
    private Image grassImage;
    private Image rockImage;

    public void switchMap(MapType mapType, Player player) {
        this.player = player; // Assign player
        switch (mapType) {
            case Starting_Area:
                setupStartArea(player);
                break;
            case MAP_2:
                // Load map 2
                break;
            case MAP_3:
                // Load map 3
                break;
            case MAP_4:
                // Load map 4
                break;
            default:
                System.out.println("Invalid map type");
        }
    }

    private void setupStartArea(Player player) {
        BorderPane startArea = new BorderPane();
        InformationGUI.InitializeInfoGUI(startArea, player);

        // Create a GridPane for the map tiles
        GridPane mapGrid = new GridPane();

        // Load images once and cache them
        grassImage = new Image("Texture/Ground/Grass/grass.jpg", 50, 50, false, false);
        rockImage = new Image("Texture/Ground/Rock/rock.png", 50, 50, false, false);

        // Create a Task to load the map asynchronously
        Task<Void> loadMapTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                // Load the entire map data into memory
                mapData = loadMapData("resources/Maps/StartingArea/StartingArea.txt");

                // Update the viewport based on the player's starting position
                updateViewport(mapGrid);
                return null;
            }
        };

        // Set what happens after the task successfully completes
        loadMapTask.setOnSucceeded(event -> {
            // Add the GridPane to the center of the BorderPane
            startArea.setCenter(mapGrid);

            // Add the player to the initial position
            player.updatePlayerPosition(mapGrid, player.getPositionRow(), player.getPositionColumn());
        });

        // Start the task in a new thread
        new Thread(loadMapTask).start();

        // Create a scene with the BorderPane
        Scene startScene = new Scene(startArea);
        Stage startStage = new Stage();
        startStage.setScene(startScene);
        startStage.setTitle("Starting Area");
        startStage.setFullScreen(true);

        // Display the start stage
        startStage.show();

        // Handle player movement
        startScene.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case UP:
                    player.moveUp();
                    break;
                case DOWN:
                    player.moveDown();
                    break;
                case LEFT:
                    player.moveLeft();
                    break;
                case RIGHT:
                    player.moveRight();
                    break;
            }
            updateViewport(mapGrid); // Update the viewport based on new player position
        });
    }

    private String[][] loadMapData(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        int rows = 0;
        int cols = 0;

        // First, determine the size of the map
        while ((line = reader.readLine()) != null) {
            cols = line.split(",").length;
            rows++;
        }
        reader.close();

        // Create the map data array
        String[][] mapData = new String[rows][cols];

        // Read the file again to populate the map data array
        reader = new BufferedReader(new FileReader(filename));
        int row = 0;
        while ((line = reader.readLine()) != null) {
            String[] tiles = line.split(",");
            for (int col = 0; col < tiles.length; col++) {
                mapData[row][col] = tiles[col].trim(); // Store the string representation of the tile
            }
            row++;
        }
        reader.close();

        return mapData;
    }

    private void updateViewport(GridPane pane) {
        Platform.runLater(() -> {
            pane.getChildren().clear();  // Clear the grid

            // Calculate the start and end indices for the rows and columns in the viewport
            int startRow = Math.max(player.getPositionRow() - viewportRows / 2, 0);
            int endRow = Math.min(startRow + viewportRows, mapData.length);
            int startCol = Math.max(player.getPositionColumn() - viewportCols / 2, 0);
            int endCol = Math.min(startCol + viewportCols, mapData[0].length);

            // Populate the GridPane with only the visible portion of the map
            for (int row = startRow; row < endRow; row++) {
                for (int col = startCol; col < endCol; col++) {
                    String tile = mapData[row][col];
                    if (tile.equals("g")) {
                        setTileBackground(pane, row - startRow, col - startCol, grassImage, null);
                    } else if (tile.equals("r")) {
                        setTileBackground(pane, row - startRow, col - startCol, null, rockImage);
                    } else if (tile.equals("gr")) {
                        setTileBackground(pane, row - startRow, col - startCol, grassImage, rockImage);
                    }
                }
            }

            // Update the player position on the grid based on the current position
            player.updatePlayerPosition(pane, startRow, startCol);
        });
    }

    private void setTileBackground(GridPane pane, int row, int col, Image backgroundImage, Image overlayImage) {
        Pane tilePane = new Pane();
        tilePane.setPrefSize(50, 50);  // Ensure each tile pane is 50x50

        if (backgroundImage != null) {
            BackgroundSize backgroundSize = new BackgroundSize(50, 50, false, false, false, false);
            BackgroundImage bgImage = new BackgroundImage(
                    backgroundImage,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.DEFAULT,
                    backgroundSize
            );
            Background background = new Background(bgImage);
            tilePane.setBackground(background);
        }

        if (overlayImage != null) {
            ImageView overlayImageView = new ImageView(overlayImage);
            overlayImageView.setFitWidth(50);
            overlayImageView.setFitHeight(50);
            tilePane.getChildren().add(overlayImageView);
        }

        // Add the pane to the grid at the specified row and column
        pane.add(tilePane, col, row);
    }
}
