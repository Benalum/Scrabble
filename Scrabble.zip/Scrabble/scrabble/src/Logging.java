/*
Creator: Alex Hartel
Creates a log file for easy to understand flow of the program for debugging purposes.
Created February 2024 for Scrabble assignment
 */


import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.io.IOException;


public class Logging {
    private static Logger logger = Logger.getLogger("Logger");
    private static FileHandler fileHandler;

    static {
        try {
            // Configure the logger with handler and formatter
            fileHandler = new FileHandler("resources/logging.txt", true); // Append mode is true
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException | IOException e) {
            logger.log(Level.SEVERE, "Error occur in FileHandler.", e);
        }
    }

    /*

    Log general information

     */

    public static void logInfo(String message) {
        logger.log(Level.INFO, message);
    }

    /*

    Log issues that need to be addressed soon

     */

    public static void logWarning(String message) {
        logger.log(Level.WARNING, message);
    }

    /*

    Log issues that need to be addressed ASAP

     */

    public static void logError(String message) {
        logger.log(Level.SEVERE, message);
    }

}
