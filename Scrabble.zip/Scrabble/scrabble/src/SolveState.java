import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class SolveState {
    private LetterTree dictionary;
    private Board board;
    private List<Character> rack;
    private Map<Position, List<Character>> crossCheckResults;
    private String direction;
    private List<Position> anchors; //list to hold anchor positions

    public SolveState(LetterTree dictionary, Board board, List<Character> rack) {
        this.dictionary = dictionary;
        this.board = board;
        this.rack = new ArrayList<>(rack);
        this.crossCheckResults = new HashMap<>();
        this.direction = null;
        this.anchors = new ArrayList<>();
    }

    public void legalMove(String word, Position lastPos) {
        System.out.println("found a word: " + word);
        Board boardIfWePlayedThat = this.board.copy();

        System.out.print("\nLast position: " + lastPos);

        Position playPos = lastPos;
        int wordIdx = word.length() - 1;
        while (wordIdx >= 0) {
            boardIfWePlayedThat.setTile(playPos, word.charAt(wordIdx));
            wordIdx--;
            playPos = this.before(playPos);
        }

        boardIfWePlayedThat.printBoard();
    }

    private Position before(Position posa) {
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        if(direction.equals("we")){
            return new Position(row,col - 1);
        }
        else {
            return new Position(row - 1, col);
        }
    }

    private Position after(Position posa) {
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        if(direction.equals("we")){
            return new Position(row,col + 1);
        }
        else {
            return new Position(row + 1, col);
        }
    }

    private Position beforeCross(Position pos){
        int[] posa = pos.returnIntArray();
        int row = posa[0];
        int col = posa[1];
        if(direction.equals("we")){
            return new Position(row - 1,col);
        }
        else {
            return new Position(row, col - 1);
        }
    }

    private Position afterCross(Position posa){
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        if(direction.equals("we")){
            return new Position(row + 1,col);
        }
        else {
            return new Position(row, col + 1);
        }
    }

    private Map<Position, List<Character>> crossCheck() {
        Map<Position, List<Character>> result = new HashMap<>();
        for (Position pos : this.board.allPositions()) {
            // Skip already filled positions
            if (this.board.isFilled(pos)) {
                //System.out.print("\nis filled: " + this.board.isFilled(pos) + Arrays.toString(pos.returnIntArray()));
                continue;
            }

            // Find letters before the current position
            String lettersBefore = "";
            Position scanPos = pos;
            while ((this.direction != null && !this.direction.isEmpty()) && this.board.isFilled(this.beforeCross(scanPos)) ) {
                scanPos = this.beforeCross(scanPos);
                lettersBefore = this.board.getTile(scanPos).getAlphabeticLetter() + lettersBefore;
                //System.out.print("\nLetters Before: " + lettersBefore);
            }

            //if(!lettersBefore.isEmpty()) {
            //    System.out.print("\nWordBefore: " + lettersBefore);
            //}
            // Find letters after the current position

            StringBuilder lettersAfter = new StringBuilder();
            scanPos = pos;
            while ((this.direction != null && !this.direction.isEmpty()) && this.board.isFilled(this.afterCross(scanPos))) {
                scanPos = this.afterCross(scanPos);
                lettersAfter.append(this.board.getTile(scanPos).getAlphabeticLetter());
            }

            //if(!lettersAfter.isEmpty()) {
            //    System.out.print("\nWordAfter: " + lettersAfter);
            //}

            // Determine the legal characters for this position
            List<Character> legalHere = new ArrayList<>();

            if (lettersBefore.isEmpty() && (lettersAfter.isEmpty())) {
                // If there are no constraints, add all alphabets
                for (char letter = 'a'; letter <= 'z'; letter++) {
                    legalHere.add(letter);
                }
            } else {
                // Otherwise, add only letters that form a valid word
                for (char letter = 'a'; letter <= 'z'; letter++) {
                    String wordFormed = lettersBefore + letter + lettersAfter;
                    if (this.dictionary.isWord(wordFormed)) {
                        //System.out.print("\nWord formed: " + wordFormed);
                        legalHere.add(letter);
                    }
                }
            }result.put(pos, legalHere);
        }
        return result;
    }

    public List<Position> findAnchors() {
        anchors.clear();
        for (int row = 0; row < board.getRowsOfBoard(); row++) {
            for (int col = 0; col < board.getColsOfBoard(); col++) { // Assuming you have a getColsOfBoard method
                Position pos = new Position(row, col);
                boolean isEmpty = board.isEmpty(pos);
                boolean hasFilledNeighbor = board.hasFilledNeighbor(pos);

                //System.out.println("Checking position: " + pos + ", Is Empty: " + isEmpty + ", Has Filled Neighbor: " + hasFilledNeighbor);

                if (isEmpty && hasFilledNeighbor) {
                    anchors.add(pos);
                    //System.out.println("Added anchor: " + pos);
                }
            }
        }
        return anchors;
    }

    public void beforePart(String partialWord, LetterTreeNode currentNode, Position anchorPos, int limit) {
        //System.out.print("\nThis is broken: " + partialWord + "\nBroken here: " + partialWord);
        this.extendAfter(partialWord, currentNode, anchorPos, false);
        //System.out.print("\nBroken here");

        if (limit > 0) {
            for (Map.Entry<Character, LetterTreeNode> entry : currentNode.getChildren().entrySet()) {
                char nextLetter = entry.getKey();
                boolean usedWildcard = false;

                if (this.rack.contains(nextLetter)) {
                    this.rack.remove(Character.valueOf(nextLetter));
                } else if (this.rack.contains('*')) {
                    this.rack.remove(Character.valueOf('*'));
                    usedWildcard = true;
                } else {
                    continue; // Skip if neither the letter nor a wildcard is available
                }

                this.beforePart(
                        partialWord + nextLetter,
                        entry.getValue(),
                        anchorPos,
                        limit - 1
                );

                // Add back what was removed (either the letter itself or a wildcard)
                if (usedWildcard) {
                    this.rack.add('*');
                } else {
                    this.rack.add(nextLetter);
                }
            }
        }
    }


    public void extendAfter(String partialWord, LetterTreeNode currentNode, Position nextPos, boolean anchorFilled) {
        if (!board.inBounds(nextPos)) {
            return; // Skip positions outside the board
        }

        if (!board.isFilled(nextPos) && currentNode.isWord() && anchorFilled) {
            legalMove(partialWord, before(nextPos));
            return; // Exit after placing the first valid word
        }

        if(anchorFilled){
            //System.out.print("\nRack: " + this.rack);
            System.out.print("\n part: " + partialWord);
        }

        if(!board.isFilled(nextPos) && currentNode.isWord && anchorFilled){
            System.out.print("WORD FOUND");
            legalMove(partialWord, before(nextPos));
        }

        // Attempt to extend the word if the next position is empty
        if (board.isEmpty(nextPos)) {
            List<Character> possibleCharacters = this.crossCheckResults.get(nextPos);
            //System.out.print("\npossible characters: " + possibleCharacters);
            if (possibleCharacters == null) {
                //System.out.print("\nNo possible characters at " + nextPos);
                return; // No valid characters to extend with
            }

            for (Map.Entry<Character, LetterTreeNode> entry : currentNode.getChildren().entrySet()) {
                char nextLetter = entry.getKey();
                if (this.rack.contains(nextLetter) && possibleCharacters.contains(nextLetter)) {
                    this.rack.remove(Character.valueOf(nextLetter));
                    //System.out.print("\nPartial word: " + partialWord + nextLetter);
                    this.extendAfter(
                            partialWord + nextLetter,
                            entry.getValue(),
                            this.after(nextPos),
                            true
                    );
                    this.rack.add(nextLetter); // Add the letter back to the rack after recursive call
                }
            }

            // Include wildcard character '*' if available in the rack
            if (this.rack.contains('*')) {
                this.rack.remove(Character.valueOf('*'));
                // Extend with the wildcard character for all possible letters
                for (char letter = 'a'; letter <= 'z'; letter++) {
                    this.extendAfter(
                            partialWord + letter,
                            currentNode,
                            this.after(nextPos),
                            true
                    );
                }
                this.rack.add('*'); // Add the wildcard character back to the rack
            }
        } else { // Use existing letter on the board
            char existingLetter = board.getTile(nextPos).getAlphabeticLetter().charAt(0);
            if (currentNode.getChildren().containsKey(existingLetter)) {
                //System.out.print("\nPartial word: " + partialWord + existingLetter);
                this.extendAfter(
                        partialWord + existingLetter,
                        currentNode.getChildren().get(existingLetter),
                        this.after(nextPos),
                        true
                );
            }
        }
    }

    public void findAllOptions() {
        this.direction = "we"; // Let's focus on 'across' moves first

        List<Position> anchors = this.findAnchors(); // Find anchors
        this.crossCheckResults = this.crossCheck(); // Perform cross-checks

        for (Position anchorPos : anchors) {
            // Check if square before anchor is filled, if so, use the existing word to the left as the start
            if (board.isFilled(this.before(anchorPos))) {
                extendExistingWord(anchorPos);
            } else {
                // Try to create new words starting at the anchor
                startNewWord(anchorPos);
            }
        }
    }

    private void extendExistingWord(Position anchorPos) {
        Position scanPos = this.before(anchorPos);
        StringBuilder partialWord = new StringBuilder(board.getTile(scanPos).getAlphabeticLetter());

        while (board.isFilled(this.before(scanPos))) {
            scanPos = this.before(scanPos);
            partialWord.insert(0, board.getTile(scanPos).getAlphabeticLetter());
        }

        LetterTreeNode node = dictionary.lookup(partialWord.toString());
        if (node != null) {
            extendAfter(partialWord.toString(), node, anchorPos, true);
        }
    }

    private void startNewWord(Position anchorPos) {
        int limit = 0;
        Position scanPos = anchorPos;

        while (board.isEmpty(this.before(scanPos)) && this.before(scanPos).withinGrid(board.getRowsOfBoard(), board.getColsOfBoard())) {
            limit++;
            scanPos = this.before(scanPos);
        }

        beforePart("", LetterTree.getRoot(), anchorPos, limit);
    }


/*
    public void findAllOptions() {
        for (String direction : new String[] {"we", "ns"}) {
            //System.out.print("\nDirection: " + direction);
            this.direction = direction;

            List<Position> anchors = this.findAnchors();
            //System.out.print("\nAnchors: " + anchors);

            this.crossCheckResults = this.crossCheck();
            //System.out.print("\nCross-check results: " + this.crossCheckResults);

            for (Position anchorPos : anchors) {

                if (board.isFilled(this.before(anchorPos))) {
                    Position scanPos = this.before(anchorPos);
                    StringBuilder partialWord = new StringBuilder(board.getTile(scanPos).toString());

                    while (board.isFilled(this.before(scanPos))) {
                        // Gets all words on board
                        scanPos = this.before(scanPos);
                        partialWord.insert(0, board.getTile(scanPos).getAlphabeticLetter());
                        //System.out.print("\nWord: " + partialWord);
                    }
                    // Remove spaces and all letters will be lower case
                    partialWord = new StringBuilder(partialWord.toString().toLowerCase().replace(" ", ""));

                    LetterTreeNode pwNode = dictionary.lookup(partialWord.toString());

                    //if(dictionary.isWord(partialWord.toString())) {
                    //    System.out.print("\nWord:" + partialWord + " is in dictionary: " + dictionary.isWord(partialWord.toString()));
                    //}

                    if (pwNode != null) {
                        this.extendAfter(String.valueOf(partialWord), pwNode, anchorPos, true);
                    }

                } else {
                    //System.out.print("\nMade it here");
                    int limit = 0;
                    Position scanPos = anchorPos;
                    while (scanPos.withinGrid(board.getRowsOfBoard(), board.getColsOfBoard()) && board.isEmpty(this.before(scanPos)) && !anchors.contains(this.before(scanPos))) {
                        //System.out.print("\nMade it here");
                        limit+=1;
                        scanPos = this.before(scanPos);
                    }
                    this.beforePart("", LetterTree.getRoot(), anchorPos, limit);
                }
            }
        }
    }

 */


    public static void main(String[] args) throws FileNotFoundException {
        // Sample usage
        LetterTree dictionary = LetterTree.basicEnglish();
        //System.out.print(dictionary.isWord("hello"));
        Board gameBoard = new Board(new File("resources/example_input.txt"),0);
        gameBoard.printBoard();
        List<Character> rack = new ArrayList<>(List.of('l','e','*','m','d','o','e'));
        System.out.print("\nrack: " + rack);
        SolveState solver = new SolveState(dictionary, gameBoard, rack);

        // Issue with recursion??
        // solver.findAllOptions();
        /*
        for (Position x : solver.findAnchors()){
            solver.board.setTile(x,'P');
        }

        // Anchors work
        solver.board.printBoard();


        */

        /*
        // Finds all available spots
        solver.findAllOptions();

        for(Map.Entry<Position,List<Character>> entry : solver.crossCheckResults.entrySet()){
            solver.board.setTile(entry.getKey(), 'P');
            System.out.print("\nEntry Key: " + entry.getKey());
        }

         */

        solver.findAllOptions();
        gameBoard.printBoard();
        //System.out.print("\nEnd");
    }
}
