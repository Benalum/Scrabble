import java.util.HashMap;
import java.util.Map;

public class LetterTreeNode {
    boolean isWord;
    Map<Character, LetterTreeNode> children;

    public LetterTreeNode(boolean isWord) {
        this.isWord = isWord;
        this.children = new HashMap<>();
    }

    public Map<Character, LetterTreeNode> getChildren() {
        return children;
    }

    public boolean isWord(String word) {
        LetterTreeNode node = LetterTree.getRoot(); // start from the current node
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            //System.out.print("\nLetter: " + c + " contains: " + node.children.containsKey(c));
            if (!node.children.containsKey(c)) {
                //System.out.print("\nWord is not a word because of: " + c + " at index: " + i);
                return false; // character not found, so it's not a word
            }
            node = node.children.get(c); // move to the next node
        }
        //if(node.isWord) {
        //    System.out.print("\nWORD: " + word);
        //}
        return node.isWord; // check if the node is marked as a word
    }
    public boolean isWord() {
        LetterTreeNode node = LetterTree.getRoot(); // start from the current node
        return node.isWord; // check if the node is marked as a word
    }
}
