/*
Creator: Alex Hartel
Used to create and manipulate the TilesValue
Created February 2024 for Scrabble assignment
*/


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TileValues {
    private static final String FILE_READ_ERROR_MSG = "Error reading file: ";
    private static final String FILE_EMPTY_MSG = "File is empty.";
    private static final String TILE_VALUE_FORMAT = "%c %d %d";

    static final File filePathForTileValues = new File("resources/scrabble_tiles.txt");
    ArrayList<TileValues> temp;
    char letter;
    int value;
    int quantity;

    /*

    Creates TileVales

     */

    public TileValues(char x, int amountValue, int amountQuantity){
        this.letter = x;
        this.value = amountValue;
        this.quantity = amountQuantity;
    }

    /*

    puts all tiles that are read from text tile into a List of TileValues

     */

    public static List<TileValues> readTileValues(File file) {
        List<TileValues> tileValues = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            tileValues = reader.lines()
                    .map(line -> line.split(" "))
                    .filter(parts -> parts.length == 3)
                    .map(parts -> new TileValues(parts[0].charAt(0),
                            Integer.parseInt(parts[1]), Integer.parseInt(parts[2])))
                    .collect(Collectors.toList());

            if (tileValues.isEmpty()) {
                //Logging.logInfo(FILE_EMPTY_MSG);
            } else {
                //Logging.logInfo("Success reading in tile values");
            }
        } catch (FileNotFoundException e) {
            Logging.logError(FILE_READ_ERROR_MSG + e.getMessage());
        } catch (IOException e) {
            Logging.logError("IO error: " + e.getMessage());
        }
        return tileValues;
    }

    /*

    find letter return all

     */

    public int getScoreFromLetter(char x){
        if(x == this.letter){
            return this.value;
        }
        return -1;
    }

    /*

    returns letter of tile

     */

    public char getLetter() {
        return letter;
    }

    /*
    returns value of tile

     */

    public int getValue() {
        return value;
    }

    /*

    returns quantity of tile

     */

    public int getQuantity() {
        return quantity;
    }

    /*

    returns string of letter, value, and quantity.

     */

    public String toString() {
        return String.format(TILE_VALUE_FORMAT, letter, value, quantity);
    }

    /*

    Checks to see if Tile Value is empty

     */

     public boolean isEmpty(Tile x){
        return (x.hasDigit() || x.hasLetter());
     }

     /*

     Prints the Tile Value

      */

    public String printArray(){
        return letter + " " + value + " " + quantity;
    }

}
