import java.util.HashSet;
import java.util.Set;

public class StringPermutations {
    static Set<String> dictionary;

    public static Set<String> findAllPermutations(String inputString, Set<String> dictionary) {
        StringPermutations.dictionary = dictionary;
        Set<String> permutations = new HashSet<>();
        char[] chars = inputString.toCharArray();
        backtrack(chars, 0, permutations);
        return permutations;
    }

    private static void backtrack(char[] chars, int start, Set<String> permutations) {
        if (start == chars.length - 1) {
            String word = new String(chars);
            if (dictionary.contains(word)) {
                permutations.add(word);
            }
            return;
        }
        for (int i = start; i < chars.length; i++) {
            swap(chars, start, i);
            backtrack(chars, start + 1, permutations);
            swap(chars, start, i); // backtrack
        }
    }

    private static void swap(char[] chars, int i, int j) {
        char temp = chars[i];
        chars[i] = chars[j];
        chars[j] = temp;
    }
}
