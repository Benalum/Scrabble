/*
Creator: Alex Hartel
Main for controlling Scrabble
Created February 2024 for Scrabble assignment
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Optional;
import java.util.Scanner;
import java.util.Timer;


public class main {
    private static final File filePathForTiles = new File("resources/scrabble_tiles.txt");
    private static final File filePathForBoard = new File("resources/scrabble_board.txt");
    private static char letterToRepresentBlankOnBoard;

    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        Scanner scanner = new Scanner(System.in);
        // Create boneYard
        BoneYard boneYard = new BoneYard(filePathForTiles);
        // Create hand
        Hand hand = new Hand(boneYard);
        Hand computerHand = new Hand(boneYard);
        // Create board and get character that represents empty
        Board board = new Board(filePathForBoard);
        board.printBoard();
        letterToRepresentBlankOnBoard = board.findBlankUsedForBoard();
        boolean isPlayerTurn = true;
        boolean gameIsRunning = true;
        boolean isFirstTurn = true;
        boolean isDebugging = true;
        Hand tempHand = new Hand();

        System.out.print("\n");
        hand.printHand();
        System.out.print("\n");

        while (gameIsRunning) {
            while (isPlayerTurn && hand.sizeOf() > 0) {
                int tileNumber = -1;

                // Prompt user for valid tile number
                while (tileNumber < 0 || tileNumber >= hand.sizeOf()) {
                    System.out.println("Enter a tile number from your hand (0-" + (hand.sizeOf() - 1) + "): ");
                    tileNumber = scanner.nextInt();
                    if (tileNumber < 0 || tileNumber >= hand.sizeOf()) {
                        System.out.println("Invalid tile number. Please enter a number within the range.");
                    }
                }

                // Move the selected tile to tempHand
                tempHand.addTileToHand(hand.getHandTile(tileNumber));
                hand.remove(tileNumber);

                if (isDebugging) {
                    System.out.print("\nTemp hand: ");
                    tempHand.printHand();

                    System.out.print("\nHand: ");
                    hand.printHand();
                }

                // Prompt user for row and column
                System.out.println("Enter the row: ");
                String row = scanner.next();

                System.out.println("Enter the column: ");
                String col = scanner.next();

                System.out.println("Enter 'play' to play tiles or any other key to continue: ");
                String userInput = scanner.next();
                if (userInput.equalsIgnoreCase("play")) {
                    // Check if valid and then play
                    isPlayerTurn = false;
                    // Check if invalid then continue questioning
                }
            }
            // Check if the game is over
            if (!gameIsRunning) {
                System.out.print("Game Over");
            }
            System.out.println("Exiting. Thank you!");
            Timer timer = new Timer();
            Thread.sleep(5000);
            System.exit(0);
        }
    }


    private static boolean isValidPosition(String position) {
    // Add your position validation logic here (e.g., check if it's a valid cell on the board)
    // For simplicity, assume any position is valid in this example
    return true;
    }

}
