/*
Creator: Alex Hartel
Reads specifically styled text files based on what will be used and creates a HashSet of those words
Created February 2024 for Scrabble assignment
Order Fixed
 */


import java.io.*;
import java.util.HashSet;
import java.util.Set;


public class ReadInWords{

    private Set<String> dictionary;

    /*

    return the dictionary

     */

    public Set<String> getDictionary() {
        return dictionary;
    }

    /*

    the dictionary is the list of words from the text file

     */

    public ReadInWords(File textFile) {
        this.dictionary = readWordsFromFile(textFile);
    }

    /*

    returns true if the word is in the Hashset

     */

    public boolean contains(String word){
        return dictionary.contains(word);
    }

    /*

    Read line for line of the documeny, not adding anything with a space and any blank lines.

     */

    private Set<String> readWordsFromFile(File textFile) {
        Set<String> words = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(textFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains(" ") & !line.isBlank()) { // Use isBlank to check for empty or whitespace-only lines
                    words.add(line);
                }
            }
        } catch (FileNotFoundException e) {
            Logging.logError("File not found: " + textFile);
            throw new RuntimeException(e); // Consider a more specific exception
        } catch (IOException e) {
            Logging.logError("Error reading file: " + textFile);
            throw new RuntimeException(e); // Consider a more specific exception
        }

        if (words.isEmpty()) {
            Logging.logError("No words found in file: " + textFile);
        } else {
            //Logging.logInfo("File read successfully with " + words.size() + " words.");
        }
        return words;
    }

    /*

    main

     */

    public static void main(String[] args) {
        try {
            ReadInWords readInWords = new ReadInWords(new File("resources/WordListPartial.txt"));
            // Example usage of the dictionary
            Set<String> dictionary = readInWords.getDictionary();
            // Perform operations with the dictionary here
            System.out.println(dictionary);
        } catch (RuntimeException e) {
            // Handle exception
        }

    }
}
