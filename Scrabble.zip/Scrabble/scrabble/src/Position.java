public class Position {
    private int col;
    private int row;

    // Constructor
    public Position(int row, int col) {
        this.row = row;
        this.col = col;

    }

    public boolean withinGrid(int maxRow, int maxCol){
        if(this.row >= 0 && this.row < maxRow && this.col >= 0 && this.col < maxCol){
            return true;
        }
        else{
            return false;
        }
    }

    // Getter for column
    public int getCol() {
        return col;
    }

    // Getter for row
    public int getRow() {
        return row;
    }

    public int[] returnIntArray(){
        return new int[] {row,col};
    }

    // Override toString for easy printing of Position objects
    @Override
    public String toString() {
        return "Position{" +
                "row=" + row +
                ", col=" + col +
                '}';
    }
}
