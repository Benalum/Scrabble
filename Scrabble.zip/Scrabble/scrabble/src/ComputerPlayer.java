import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ComputerPlayer {
    static final File filePathForWords = new File("resources/sowpods.txt");
    final File filePathForTileValues = new File("resources/scrabble_tiles.txt");
    static final File filePathForBoardForComputerPlayer = new File("resources/example_input.txt");
    private static ReadInWords dictionary = new ReadInWords(filePathForWords);
     List<TileValues> tileValues;
    static Trie root;
    public ComputerPlayer(File filePath) throws FileNotFoundException {
        boolean isRunning = true;
        int index = 0;

        //Create List
        List<String> wordsNextToLettersPlaced = new ArrayList<>();

        // Create Trie
        Trie root = new Trie();

        // Place words in Trie
        for (String word : dictionary.getDictionary()) {
            root.insert(word);
        }

        while (isRunning) {
            try {
                Board board = new Board(filePath, index);

                index += (board.getRowsOfBoard() + 1);
                String hand = board.getLineReader(index, filePath);
                index++;
                System.out.print("\nInput Board:");
                board.printBoard();
                System.out.print("\nTray: " + hand);

                playBestPlayOnBoard(hand, board);
                // Get hand letters, get letters on board, figure out best play.

                tileValues = TileValues.readTileValues(filePathForTileValues);
                List<WordValuePair> wordValuePairs = new ArrayList<>();


                List<String> playableWordsAndScore = new ArrayList<>();

            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

        }
    }

    private void playBestPlayOnBoard(String hand, Board board){
        Board bestPlayBoard = board;

        for(int row = 0; row < board.getRowsOfBoard(); row++){
            for (int col = 0; col < board.getColsOfBoard(); col++){
                if(board.getTileOnBoard(row,col).hasLetter()){
                    System.out.print("\nLeter: " + board.getTileOnBoard(row, col).getAlphabeticLetter());
                    checkCurrentIndexForPlay(hand, board, board.getEmpySpacesToTheTopOfLetter(row, col), board.getEmpySpacesToTheBottomOfLetter(row, col), board.getEmptySpacesToTheRightOfLetter(row, col), board.getEmptySpacesToTheLeftOfLetter(row, col));
                    break;
                }
                // compare boards to see highest score
                // keep highest scored board
            }

        }
        //return board
    }


    private void checkCurrentIndexForPlay(String hand, Board board, int spaceAboveLetter, int spaceBelowLetter, int spaceRightOfLetter, int spaceLeftOfLetter){
        System.out.print("\nAbove: " + spaceAboveLetter + " Below: " + spaceBelowLetter + " Right: " + spaceRightOfLetter + " Left: " + spaceLeftOfLetter);

        //return board
    }

    private Board tryToPlayWord(String word, int score, Board board){
        for(int row = 0; row < board.getRowsOfBoard(); row++){
            for(int col = 0; col < board.getColsOfBoard(); col++){
                if(board.getTileOnBoard(row,col).hasLetter()){
                    if(board.getTileOnBoard(row,col).getAlphabeticLetter().charAt(0) == (word.charAt(0))){
                        Board newBoard = tryToPlayHorizontalPlacement(word, board, tileValues, score);
                        //System.out.print("\n1");
                        if(newBoard != board) {
                            System.out.print("\nNEW BOARD");
                            return newBoard;
                        }
                        //System.out.print("\n2");
                        newBoard = tryToPlayVerticalPlacement(word, board, tileValues, score);
                        if(newBoard != board) {
                            System.out.print("\nNEW BOARD");
                            return newBoard;
                        }
                        //System.out.print("\n3");
                    }
                }
            }
        }
        return board;
    }

    private Board tryToPlayVerticalPlacement(String word, Board board, List<TileValues> tileVales, int scoreToFind) {

        int rows = board.getRowsOfBoard();
        int cols = board.getColsOfBoard();

        int wordScoreMultiplierUp = 1;
        int wordScoreMultiplierDown = 1;
        int wordScoreMultiplierUpHighest = 1;
        int wordScoreMultiplierDownHighest = 1;

        Board newBoard = board;

        int wordScoreUp = 0;
        int wordScoreDown = 0;
        int wordScoreUpHighest = 0;
        int wordScoreDownHighest = 0;

        // Search the board for letters, if letter is start or end of word and can place save highest one
        for (int row = 0; row < rows; row++) {

            for (int col = 0; col < cols; col++) {

                if (board.getTileOnBoard(row, col).hasLetter()) {

                    char temp = board.getTileOnBoard(row, col).getAlphabeticLetter().charAt(0);
                    if (temp == (word.charAt(0))) {
                        // Check if enough room downwards

                        // get word score
                        for (int k = 0; k < word.length() - 1; k++) {
                            //System.out.print("\nSearching");
                            if (row + k < board.getRowsOfBoard()) {
                                if (board.getTileOnBoard(row + k, col).hasDigit()) {
                                    if (board.getTileOnBoard(row + k, col).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierDown *= Integer.parseInt(board.getTileOnBoard(row + k, col).getNumber());
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row + k, col).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreDown += Integer.parseInt(board.getTileOnBoard(row + k, col).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row + k, col).hasLetter()) {
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    }
                                }
                                if (wordScoreMultiplierDownHighest * wordScoreDownHighest < wordScoreDown * wordScoreMultiplierDown) {
                                    System.out.print("\nIN DOWN CHECK: " + wordScoreDown * wordScoreMultiplierDown);
                                    wordScoreDownHighest = wordScoreDown;
                                    wordScoreMultiplierDownHighest = wordScoreMultiplierDown;
                                }
                            }
                            if (wordScoreDown * wordScoreMultiplierDown == scoreToFind) {
                                System.out.print("\nFOUND IN DOWN");
                                //place score on board
                                for (int p = 0; p < word.length() - 1; p++) {
                                    newBoard.placeTileOnBoard(row + p, col, new Tile(" ", word.charAt(p) + ""));
                                }
                                System.out.print("\nNew board:");
                                return newBoard;
                            }
                        }

                        for (int k = 0; k < word.length() - 1; k++) {
                            if (row - k >= 0 && row + k < board.getRowsOfBoard()) {
                                if (board.getTileOnBoard(row - k, col).hasDigit()) {
                                    if (board.getTileOnBoard(row - k, col).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierUp *= Integer.parseInt(board.getTileOnBoard(row - k, col).getNumber());
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row - k, col).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreUp += Integer.parseInt(board.getTileOnBoard(row - k, col).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row - k, col).hasLetter()) {
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    }
                                }
                                if (wordScoreMultiplierUpHighest * wordScoreUpHighest < wordScoreUp * wordScoreMultiplierUp) {
                                    wordScoreUpHighest = wordScoreUp;
                                    wordScoreMultiplierUpHighest = wordScoreMultiplierUp;
                                    System.out.print("\nIN UP CHECK: " + wordScoreUp * wordScoreMultiplierUp);
                                }
                            }
                        }
                        if (wordScoreUp * wordScoreMultiplierUp == scoreToFind) {
                            System.out.print("\nFOUND IN UP");
                            //place score on board
                            for (int p = 0; p < word.length() - 1; p++) {
                                newBoard.placeTileOnBoard(row - p, col, new Tile(" ", word.charAt(p) + ""));
                            }
                            System.out.print("\nNew board:");
                            return newBoard;
                        }
                    }
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
                if (row == rows - 1 & col == cols - 1) {
                    break;
                }
            }
        }
        return board;
    }

    private Board tryToPlayHorizontalPlacement(String word, Board board, List<TileValues> tileValues, int scoreToFind){

        int rows = board.getRowsOfBoard();
        int cols = board.getColsOfBoard();

        int wordScoreMultiplierUp = 1;
        int wordScoreMultiplierDown = 1;
        int wordScoreMultiplierUpHighest = 1;
        int wordScoreMultiplierDownHighest = 1;

        Board newBoard = board;

        int wordScoreUp = 0;
        int wordScoreDown = 0;
        int wordScoreUpHighest = 0;
        int wordScoreDownHighest = 0;

        // Search the board for letters, if letter is start or end of word and can place save highest one
        for (int row = 0; row < rows; row++) {

            for (int col = 0; col < cols; col++) {

                if(board.getTileOnBoard(row,col).hasLetter()){

                    char temp = board.getTileOnBoard(row,col).getAlphabeticLetter().charAt(0);
                    if(temp == (word.charAt(0))){

                        // get word score
                        for(int k = 0; k < word.length(); k++){
                            if(col + k < board.getColsOfBoard()) {
                                if (board.getTileOnBoard(row, col + k).hasDigit()) {
                                    if (board.getTileOnBoard(row ,col + k ).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierDown *= Integer.parseInt(board.getTileOnBoard(row, col + k).getNumber());
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row, col + k).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreDown += Integer.parseInt(board.getTileOnBoard(row, col + k).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row, col + k).hasLetter()) {
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                            //System.out.print("\n" + wordScoreDown * wordScoreMultiplierDown + scoreToFind);
                            if( wordScoreMultiplierDownHighest * wordScoreDownHighest < wordScoreDown * wordScoreMultiplierDown ){
                                wordScoreDownHighest = wordScoreDown;
                                wordScoreMultiplierDownHighest = wordScoreMultiplierDown;
                            }
                            //newBoard.printBoard();
                        }
                        if(wordScoreDown * wordScoreMultiplierDown == scoreToFind){
                            //place score on board
                            //System.out.print("\n\n" + row + col);
                            for(int p = 0; p < word.length() - 1; p++){
                                System.out.print("\n\n" + row + (col + p));
                                newBoard.placeTileOnBoard(row, col + p, new Tile(" ", word.charAt(p) + ""));
                            }
                            return newBoard;
                        }
                        for(int k = 0; k < word.length(); k++){
                            if(col-k >= 0 && col + k < board.getColsOfBoard()) {
                                if (board.getTileOnBoard(row, col - k).hasDigit()) {
                                    if (board.getTileOnBoard(row, col - k).getPositionOfNumber() == 0) {

                                        // left is word multiplier
                                        wordScoreMultiplierUp *= Integer.parseInt(board.getTileOnBoard(row, col - k).getNumber());
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row, col - k).getPositionOfNumber() == 1) {

                                        // right is letter multiplier
                                        wordScoreUp += Integer.parseInt(board.getTileOnBoard(row, col - k).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    }
                                } else {

                                    // no multiplier
                                    if (board.getTileOnBoard(row, col - k).hasLetter()) {
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                            if(wordScoreMultiplierUpHighest * wordScoreUpHighest < wordScoreUp * wordScoreMultiplierUp){
                                wordScoreUpHighest = wordScoreUp;
                                wordScoreMultiplierUpHighest = wordScoreMultiplierUp;
                            }
                        }
                    }
                    //newBoard.printBoard();
                    if(wordScoreDown * wordScoreMultiplierDown == scoreToFind){
                        //place score on board
                        for(int p = 0; p < word.length() - 1; p++){
                            newBoard.placeTileOnBoard(row, col - p, new Tile(" ", word.charAt(p) + ""));
                        }
                        return newBoard;
                    }
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
                if(row == rows - 1 & col == cols - 1) {
                    break;
                }
            }
        }
        return board;
    }

    public static String removeNonAlphabetic(String inputString) {
        // Use regular expression to replace non-alphabetic characters with an empty string
        return inputString.replaceAll("[^a-zA-Z]", "");
    }


    private int getScoreFromLetter(List<TileValues> tileValues, char letter) {
        for (TileValues tiles : tileValues) {
            if(Character.toLowerCase(letter) == tiles.getLetter()){
                return tiles.getValue();
            }
        }
        return 0; // return 0 for blank or non-existing tiles
    }


    private List<String> findAllHorizontalPlacements(String word, Board board, List<TileValues> tileValues){
        // Send it the board to search for letters that start or end with the word
        List<String> results = new ArrayList<>();

        int rows = board.getRowsOfBoard();
        int cols = board.getColsOfBoard();

        int wordScoreMultiplierUp = 1;
        int wordScoreMultiplierDown = 1;
        int wordScoreMultiplierUpHighest = 1;
        int wordScoreMultiplierDownHighest = 1;

        int wordScoreUp = 0;
        int wordScoreDown = 0;
        int wordScoreUpHighest = 0;
        int wordScoreDownHighest = 0;

        // Search the board for letters, if letter is start or end of word and can place save highest one
        for (int row = 0; row < rows; row++) {

            for (int col = 0; col < cols; col++) {

                if(board.getTileOnBoard(row,col).hasLetter()){

                    char temp = board.getTileOnBoard(row,col).getAlphabeticLetter().charAt(0);
                    if(temp == (word.charAt(0))){

                        // get word score
                        for(int k = 0; k < word.length(); k++){
                            if(col - k > 0 && col + k < board.getColsOfBoard()) {
                                if (board.getTileOnBoard(row, col + k).hasDigit()) {
                                    if (board.getTileOnBoard(row ,col + k ).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierDown *= Integer.parseInt(board.getTileOnBoard(row, col + k).getNumber());
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row, col + k).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreDown += Integer.parseInt(board.getTileOnBoard(row, col + k).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row, col + k).hasLetter()) {
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col + k).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                        }
                        if( wordScoreMultiplierDownHighest * wordScoreDownHighest < wordScoreDown * wordScoreMultiplierDown ){
                            wordScoreDownHighest = wordScoreDown;
                            wordScoreMultiplierDownHighest = wordScoreMultiplierDown;
                        }
                        for(int k = 0; k < word.length(); k++){
                            if(col - k >= 0 && col + k < board.getColsOfBoard()) {
                                if (board.getTileOnBoard(row, col - k).hasDigit()) {
                                    if (board.getTileOnBoard(row, col - k).getPositionOfNumber() == 0) {

                                        // left is word multiplier
                                        wordScoreMultiplierUp *= Integer.parseInt(board.getTileOnBoard(row, col - k).getNumber());
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row, col - k).getPositionOfNumber() == 1) {

                                        // right is letter multiplier
                                        wordScoreUp += Integer.parseInt(board.getTileOnBoard(row, col - k).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    }
                                } else {

                                    // no multiplier
                                    if (board.getTileOnBoard(row, col - k).hasLetter()) {
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row, col - k).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                        }
                        if(wordScoreMultiplierUpHighest * wordScoreUpHighest < wordScoreUp * wordScoreMultiplierUp){
                            wordScoreUpHighest = wordScoreUp;
                            wordScoreMultiplierUpHighest = wordScoreMultiplierUp;
                        }
                    }
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
                if(row == rows - 1 & col == cols - 1) {
                    break;
                }else {
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
            }
        }if( wordScoreDownHighest * wordScoreMultiplierDownHighest <= wordScoreUpHighest * wordScoreMultiplierUpHighest ){
            results.add(word + " " + wordScoreUpHighest +  " " + wordScoreMultiplierUpHighest);
        }else {
            results.add(word + " " + wordScoreDownHighest + " " + wordScoreMultiplierDownHighest);
        }
        return results;
    }


    private List<String> findAllVerticalPlacements(String word, Board board, List<TileValues> tileVales) {

        // Send it the board to search for letters that start or end with the word
        List<String> results = new ArrayList<>();

        int rows = board.getRowsOfBoard();
        int cols = board.getColsOfBoard();

        int wordScoreMultiplierUp = 1;
        int wordScoreMultiplierDown = 1;
        int wordScoreMultiplierUpHighest = 1;
        int wordScoreMultiplierDownHighest = 1;

        int wordScoreUp = 0;
        int wordScoreDown = 0;
        int wordScoreUpHighest = 0;
        int wordScoreDownHighest = 0;

        // Search the board for letters, if letter is start or end of word and can place save highest one
        for (int row = 0; row < rows; row++) {

            for (int col = 0; col < cols; col++) {
                if(board.getTileOnBoard(row,col).hasLetter()){
                    char temp = board.getTileOnBoard(row,col).getAlphabeticLetter().charAt(0);
                    if(temp == (word.charAt(0))){
                        // Check if enough room downwards

                        // get word score
                        for(int k = 0; k < word.length(); k++){
                            if(row + k < board.getRowsOfBoard()) {
                                if(row + k <= 0 || row + k > board.getRowsOfBoard()){
                                    wordScoreMultiplierUp = 0;
                                    wordScoreUp = 0;
                                    break;
                                }
                                if (board.getTileOnBoard(row + k, col).hasDigit()) {
                                    if (board.getTileOnBoard(row + k, col).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierDown *= Integer.parseInt(board.getTileOnBoard(row + k, col).getNumber());
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row + k, col).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreDown += Integer.parseInt(board.getTileOnBoard(row + k, col).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row + k, col).hasLetter()) {
                                        wordScoreDown += getScoreFromLetter(tileValues, board.getTileOnBoard(row + k, col).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                        }
                        if(wordScoreMultiplierDownHighest * wordScoreDownHighest < wordScoreDown * wordScoreMultiplierDown){
                            wordScoreDownHighest = wordScoreDown;
                            wordScoreMultiplierDownHighest = wordScoreMultiplierDown;
                        }


                        for(int k = 0; k < word.length(); k++){
                            if(row - k <= 0 || row - k > board.getRowsOfBoard()){
                                wordScoreMultiplierUp = 0;
                                wordScoreUp = 0;
                                break;
                            }
                            if(row - k >= 0 && row + k < board.getRowsOfBoard()) {
                                if (board.getTileOnBoard(row - k, col).hasDigit()) {
                                    if (board.getTileOnBoard(row - k, col).getPositionOfNumber() == 0) {
                                        // left is word multiplier
                                        wordScoreMultiplierUp *= Integer.parseInt(board.getTileOnBoard(row - k, col).getNumber());
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    } else if (board.getTileOnBoard(row - k, col).getPositionOfNumber() == 1) {
                                        // right is letter multiplier
                                        wordScoreUp += Integer.parseInt(board.getTileOnBoard(row - k, col).getNumber()) *
                                                getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    }
                                } else {
                                    // no multiplier
                                    if (board.getTileOnBoard(row - k, col).hasLetter()) {
                                        wordScoreUp += getScoreFromLetter(tileValues, board.getTileOnBoard(row - k, col).getAlphabeticLetter().charAt(0));
                                    }
                                }
                            }
                        }
                        if(wordScoreMultiplierUpHighest * wordScoreUpHighest < wordScoreUp * wordScoreMultiplierUp){
                            wordScoreUpHighest = wordScoreUp;
                            wordScoreMultiplierUpHighest = wordScoreMultiplierUp;
                        }
                    }
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
                if(row == rows-1 & col == cols-1) {
                    break;
                }else {
                    wordScoreMultiplierUp = 1;
                    wordScoreMultiplierDown = 1;
                    wordScoreUp = 0;
                    wordScoreDown = 0;
                }
            }

        }if( wordScoreDownHighest * wordScoreMultiplierDownHighest <= wordScoreUpHighest * wordScoreMultiplierUpHighest ){
            results.add(word + " " + wordScoreUpHighest +  " " + wordScoreMultiplierUpHighest);
        }else {
            results.add(word + " " + wordScoreDownHighest + " " + wordScoreMultiplierDownHighest);
        }

        return results;
    }


    private boolean checkHandWithWord(String word, Hand hand, char letterFromBoard){
        StringBuilder tempHand = new StringBuilder();
        for(int j = 0; j < hand.sizeOf(); j++){
            tempHand.append(hand.getHandTile(j).getAlphabeticLetter());
        }

        for(int i = 0; i < word.length(); i++){
            for(int k = 0; k < tempHand.length(); k++) {
                if (word.charAt(i) == tempHand.charAt(k)){
                    tempHand.delete(k, k+1);
                    break;
                }
            }
        }

        // Check to see if special character(blank) is left
        if(tempHand.length() > 0){
            Pattern p = Pattern.compile("a-z", Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(tempHand.toString());
            boolean b = m.find();
            if(b){
                tempHand.delete(0,1);
            }
        }
        return tempHand.length() == 0;
    }

    private boolean canPlaceWordVertically(String word, int startRow, int col, Board board) {
        int rows = board.getRowsOfBoard();

        if (startRow + word.length() > rows) {
            return false; // Word doesn't fit vertically from this position
        }

        for (int i = 0; i < word.length(); i++) {
            char letter = word.charAt(i);
            Tile tile = board.getTileOnBoard(startRow + i, col);

            if (tile.hasLetter()) {
                tile.getAlphabeticLetter();
            }

            if (!tile.hasLetter() && !tile.hasDigit()) {
                return false; // Empty tile where letter cannot be placed
            }
        }

        return true; // Word can be placed vertically from this position
    }

    private String getLettersOnBoard(Board board){
        StringBuilder word = new StringBuilder();
        for(int i = 0; i < board.getRowsOfBoard(); i++){
            for(int j = 0; j < board.getColsOfBoard(); j++){
                if(board.getTileOnBoard(i,j).hasLetter()){
                    // check for move
                }
            }
        }
        return word.toString();
    }

    public static Set<String> findAllPermutations(String inputString) {
        StringPermutations.dictionary = Collections.unmodifiableSet(dictionary.getDictionary());
        Set<String> permutations = new HashSet<>();
        char[] chars = inputString.toCharArray();
        backtrack(chars, 0, permutations);
        return permutations;
    }

    private static void backtrack(char[] chars, int start, Set<String> permutations) {
        if (start == chars.length - 1) {
            String word = new String(chars);
            if (dictionary.contains(word)) {
                permutations.add(word);
            }
            return;
        }
        for (int i = start; i < chars.length; i++) {
            swap(chars, start, i);
            backtrack(chars, start + 1, permutations);
            swap(chars, start, i); // backtrack
        }
    }

    private static void swap(char[] chars, int i, int j) {
        char temp = chars[i];
        chars[i] = chars[j];
        chars[j] = temp;
    }

    public int calculateWordValue(String word) {
        int value = 0;
        for (char letter : word.toLowerCase().toCharArray()) {
            for(TileValues tileValues1: tileValues){
                if(letter == tileValues1.getLetter()){
                    value += tileValues1.getValue();
                }
            }
        }
        return value;
    }

    private String getLettersInHandIntoString(Hand hand) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < hand.sizeOf(); i++) {
            result.append(hand.getHandTile(i).getAlphabeticLetter());
        }
        return result.toString();
    }
    

    public static void main(String[] args) throws FileNotFoundException {
        new ComputerPlayer(filePathForBoardForComputerPlayer);
    }

}
