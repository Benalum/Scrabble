class TilePosition {
    char letter;
    int row;
    int column;

    TilePosition(char letter, int row, int column) {
        this.letter = letter;
        this.row = row;
        this.column = column;
    }

    // Getters and Setters
}