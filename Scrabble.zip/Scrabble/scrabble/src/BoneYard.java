/*
Creator: Alex Hartel
Creates a shuffled boneYard that utilizes an ArrayList of Tiles
Created February 2024 for Scrabble assignment
 */


import java.io.*;
import java.util.ArrayList;
import java.util.Collections;


public class BoneYard {
   ArrayList<Tile> boneyard;

    public BoneYard(File filePath) throws FileNotFoundException {
        this.boneyard = createBoneyard(filePath);
    }

    private ArrayList<Tile> createBoneyard(File file) throws FileNotFoundException {
        ArrayList<TileValues> tileValues = readTileValues(file);
        if (!tileValues.isEmpty()) {
            //Logging.logInfo("TileValues made to produce Tiles for Boneyard");
        } else {
            Logging.logError("TileValues Error");
        }

        ArrayList<Tile> boneyard = new ArrayList<>();

        for (TileValues tileValue : tileValues) {
            int quantity = tileValue.getQuantity();
            char letter = tileValue.getLetter();
            int value = tileValue.getValue();
            for (int j = 0; j < quantity; j++) {
                boneyard.add(new Tile(String.valueOf(letter), String.valueOf(value)));
            }
        }

        if (!boneyard.isEmpty()) {
            //Logging.logInfo("Boneyard created");
        } else {
            Logging.logError("Boneyard Error");
        }

        Collections.shuffle(boneyard);

        return boneyard;
    }

    private ArrayList<TileValues> readTileValues(File file) throws FileNotFoundException {
        ArrayList<TileValues> tileValues = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] lineArray = line.split(" ");
                char letter = lineArray[0].charAt(0);
                int value = Integer.parseInt(lineArray[1]);
                int quantity = Integer.parseInt(lineArray[2]);

                tileValues.add(new TileValues(letter, value, quantity));
            }

            if (!tileValues.isEmpty()) {
                //Logging.logInfo("File read and dictionary contains words for lookup.");
            } else {
                Logging.logError("File read Nothing exists in Dictionary.");
            }
        } catch (IOException e) {
            Logging.logError("File reading error on " + file.toString());
            throw new RuntimeException(e);
        }
        return tileValues;
    }

    public void printBoneYard(){
        for(Tile bone : boneyard){
            System.out.println(bone.toString());
        }
    }

    public Tile getTile() { return boneyard.remove(0); }

    private void removeTile(Tile tile){
        boneyard.remove(tile);
    }

    public boolean isEmpty() {
        return boneyard.isEmpty();
    }

    public int sizeOf() {
        return boneyard.size();
    }

}