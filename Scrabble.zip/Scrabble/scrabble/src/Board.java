/*
Creator: Alex Hartel
Reads specifically styled text files based on what will be used and creates a Tiles 2d array board.
Created February 2024 for Scrabble assignment
Order fixed
 */


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.exit;


public class Board {
    Tile[][] board;

    private int lineOfDocument;

    public Board(int size) {
        // Initialize an empty board of given size
        board = new Tile[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = new Tile(".",".");
            }
        }
    }

    public boolean hasFilledNeighbor(Position pos) {
        int row = pos.getRow();
        int col = pos.getCol();
        int maxRow = getRowsOfBoard() - 1;
        int maxCol = getColsOfBoard() - 1;

        // Check up, if not on the top edge
        if (row > 0 && isFilled(new Position(row - 1, col))) return true;

        // Check down, if not on the bottom edge
        if (row < maxRow && isFilled(new Position(row + 1, col))) return true;

        // Check left, if not on the left edge
        if (col > 0 && isFilled(new Position(row, col - 1))) return true;

        // Check right, if not on the right edge
        if (col < maxCol && isFilled(new Position(row, col + 1))) return true;

        return false;
    }

    public List<Position> allPositions() {
        ArrayList<Position> result = new ArrayList<>();
        for (int row = 0; row < getRowsOfBoard(); row++) {
            for (int col = 0; col < getColsOfBoard(); col++) {
                result.add(new Position(col, row));
            }
        }
        //System.out.print(result);
        return result;
    }

    // Set a tile at a specific position
    public void setTile(Position posa, char tileLetter) {
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        if (row >= 0 && row < this.getRowsOfBoard() && col >= 0 && col < this.getColsOfBoard()) {
            board[row][col] = new Tile(tileLetter);
        }
    }

    // Get a tile at a specific position
    public Tile getTile(Position posa) {
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        if (row >= 0 && row < this.getRowsOfBoard() && col >= 0 && col < this.getColsOfBoard()) {
            return this.getTileOnBoard(row,col);
        }
        return null; // Return null if out of bounds
    }

    // Check if a specific position is empty
    public boolean isEmpty(Position pos) {

        try{
            return !getTile(pos).hasLetter();
        } catch (NullPointerException e) {
            return true;
        }
    }

    public boolean isFilled(Position posa) {
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        Tile tile = this.getTileOnBoard(row, col);

        // Check if tile is not null before calling hasLetter
        if (tile != null && tile.hasLetter()) {
            return true;
        }
        return false;
    }

    public Board copy(){
        Board newBoard = new Board(getRowsOfBoard());
        for (int row = 0; row < getRowsOfBoard(); row++){
            for(int col = 0; col < getColsOfBoard(); col++){
                newBoard.getTileOnBoard(row, col).placeExactlySameTile(this.getTile(new Position(row,col)));
            }
        }
        return newBoard;
    }

    public boolean inBounds(Position posa){
        int[] pos = posa.returnIntArray();
        int row = pos[0];
        int col = pos[1];
        return(row >= 0 && row < getRowsOfBoard() && col >= 0 && col < getColsOfBoard());
    }

    /*

    return an int of the number of rows on a board

     */

    int getRowsOfBoard(){
        return board.length;
    }

    /*

    return an int of columns on a board

     */

    public int getColsOfBoard(){
        if (board.length == 0) return 0;
        return board[0].length;
    }

    /*

    print board statements

     */

    public void printBoard() {
        for (Tile[] x : board){
            System.out.print("\n");
            for(Tile z : x){
                System.out.print(z.toString() + " ");
            }
        }
    }

    /*

    Set line

     */

    /*

    Get specific line

     */

    public String getLineReader(int line, File textFile) throws FileNotFoundException {
        try (BufferedReader reader = new BufferedReader(new FileReader(textFile))) {
            //skip lines
            for (int i = 0; i < line; i++) {
                reader.readLine();
            }
            return reader.readLine();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    private void setLineOfDocument(int input) {
        lineOfDocument = input;
    }

    /*

    getLineofDocument

     */

    public int getLineOfDocument(){ return lineOfDocument; }


    /*

    gets text file and creates a 2d array board of Tiles

     */

    public Board(File textFile) throws FileNotFoundException {

        int size;
        String line;
        int currentLineRow = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(textFile))) {
            // Read first line
            size = Integer.parseInt(reader.readLine());
            //System.out.println("Size is: " + size);
            board = new Tile[size][size];
            // Read lines 2 to end of document
            while ((line = reader.readLine()) != null) {
                if(currentLineRow == size){
                    break;
                }else {
                    String[] lineArray = line.split(" ");
                    //System.out.print("\n" + line);

                    int countForArray = 0;
                    for (String s : lineArray) {
                        //System.out.print(s);
                        board[currentLineRow][countForArray] = new Tile(s);
                        countForArray++;
                    }
                    //System.out.print("\n");
                    currentLineRow++;
                }
            }
            setBoard(board);
            //printBoard(board, size);
            if (!(board.length == 0)) {
                //Logging.logInfo("File read and Board is not empty.");
            } else {
                Logging.logError("File read Nothing exists in Board.");
            }
        } catch (IOException e) {
            Logging.logError("File reading error on " + textFile.toString());
            throw new RuntimeException(e);
        }

    }

     /*

    gets text file and creates a 2d array board of Tiles

     */

    public Board(File textFile, int lineNumber) throws FileNotFoundException {
        int size;
        String line;
        int currentLineRow = lineNumber;
        int lineToWatch = 1;
        int currentRowIndex = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(textFile))) {
            //skip lines
            for(int i = 0; i < lineNumber; i++){
                reader.readLine();
            }

            // Read first line
            String sizes = reader.readLine();
            try {
                while (sizes.isEmpty() || sizes.isBlank()) {
                    sizes = reader.readLine();
                    currentLineRow++;
                }
            } catch (NullPointerException e) {
                exit(1);
            }
            sizes.replaceAll("\\s+","");

            //System.out.print("Size: " + sizes);
            size = getInteger(sizes);

            board = new Tile[size][size];

            // Read lines 2 to size
            while ((line = reader.readLine()) != null & currentRowIndex <= size) {
                if(currentRowIndex == size){
                    break;
                }else {
                    String[] lineArray = line.split(" ");
                    int countForArray = 0;
                    for (String s : lineArray) {
                        try{
                            if (s.length() == 1) {
                                String[] splitMore = s.split(" ");
                                for(int r = 0; r < splitMore.length; r++){
                                    if (Character.isLetter(splitMore[r].charAt(0))){
                                        board[currentRowIndex][countForArray] = new Tile(splitMore[r].charAt(0));
                                        countForArray++;
                                    }
                                }
                            } else if (s.isEmpty()) {
                                continue;
                            } else{
                                board[currentRowIndex][countForArray] = new Tile(s);
                                countForArray++;
                            }
                        }
                        catch (IndexOutOfBoundsException i){
                            setBoard(board);
                        }
                    }
                    currentRowIndex++;
                    lineToWatch++;
                    currentLineRow++;
                }
            }
            setBoard(board);
            if (!(board.length == 0)) {
                //Logging.logInfo("File read and Board is not empty.");
            } else {
                Logging.logError("File read Nothing exists in Board.");
            }

        } catch (IOException e) {
            Logging.logError("File reading error on " + textFile.toString());
            throw new RuntimeException(e);
        };
        setLineOfDocument(currentLineRow + 1);
    }

    /*

    Set tile on board

     */

    private void setBoard(Tile[][] b){
        board = b;
    }

    /*

    get the multiplier of a tile on board

     */

    public int getMultiplierOnBoard(int row, int col){
        return Integer.parseInt(board[row][col].getNumber());
    }

    /*

    hasMultiplier search if it does

     */

    public boolean hasMultiplierOnBoard(int row, int col){
        return board[row][col].hasDigit();
    }

    /*

    get the tile on the board

     */

    public Tile getTileOnBoard(int row, int col) {
        if (row >= 0 && row < board.length && col >= 0 && col < board[row].length) {
            return board[row][col];
        } else {
            return null; // Or handle the out-of-bounds case in another appropriate way
        }
    }


    /*

    return center position on board

     */

    public boolean isCenterOfBoard(int row, int col){
        int rows = (getRowsOfBoard() + 1) / 2;
        int cols = (getColsOfBoard() + 1) / 2;
        return ( (rows == row) && (cols == col) );
    }

    /*

    Place tile from hand on board

     */

    public void placeTileOnBoard(int row, int col, Tile tileHand){
        board[row][col] = board[row][col].tilePlacementOnBoard(board[row][col], tileHand);
    }

    public void placeLetterOnBoard(int row, int col, char x){
        board[row][col] = new Tile(x);
    }

    public char findBlankUsedForBoard(){
        int rows = getRowsOfBoard();
        int cols = getColsOfBoard();
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < cols; j++){
                if(!board[i][j].hasDigit() && !board[i][j].hasLetter()){
                    return board[i][j].getEmptyCharacterFromTile();
                }
            }
        }
        Logging.logError("findBlankUsedForBoard Error. Could not determine what character it is.");
        return '-';
    }

    private boolean areBoardsCompatable(Board previousBoard, Board currentBoard){
        return (previousBoard.getRowsOfBoard() == currentBoard.getRowsOfBoard() &
                previousBoard.getColsOfBoard() == currentBoard.getRowsOfBoard());
    }

    private int getInteger(String input){
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (Character.isDigit(currentChar)) {
                digits.append(currentChar);
            }
        }
        if (digits.length() == 0) {
            return 0; // Return 0 if no digits were found
        }
        try {
            return Integer.parseInt(digits.toString());
        } catch (NumberFormatException e) {
            // Handle the case where the number is too large for an int
            System.out.println("The number extracted from the string is too large to fit in an int.");
            return 0; // Or handle this case as you see fit
        }
    }

    public void isValidMove(Board previousBoard, Board currentBoard){

        //Check if boards are same dimensions
        if(areBoardsCompatable(previousBoard, currentBoard)){

        }
        else{
        }
    }

    public int getEmptySpacesToTheLeftOfLetter(int row, int col){
        int count = 0;
        for(int colTemp = col - 1; colTemp >= 0; colTemp--){
            if(!getTileOnBoard(row, colTemp).hasLetter()){
                count++;
            }
            else{
                return count;
            }
        }

        return count;
    }

    public int getEmptySpacesToTheRightOfLetter(int row, int col){
        int count = 0;
        for(int colTemp = col + 1; colTemp < getColsOfBoard(); colTemp++){
            if(!getTileOnBoard(row, colTemp).hasLetter()){
                count++;
            }
            else{
                return count;
            }
        }
        return count;
    }

    public int getEmpySpacesToTheTopOfLetter(int row, int col){
        int count = 0;
        for(int rowTemp = row - 1; rowTemp >= 0; rowTemp--){
            if(!getTileOnBoard(rowTemp, col).hasLetter()){
                count++;
            }
            else{
                return count;
            }
        }
        return count;
    }

    public int getEmpySpacesToTheBottomOfLetter(int row, int col){
        int count = 0;
        for(int rowTemp = row + 1; rowTemp < getRowsOfBoard(); rowTemp++){
            if(!getTileOnBoard(rowTemp, col).hasLetter()){
                count++;
            }
            else{
                return count;
            }
        }
        return count;
    }




    public static void main(String[] args) throws FileNotFoundException {
/*
        int lineCount = 0;
        final File filePathForBoard = new File("resources/example_score_made.txt");
        Board previousBoard;
        Board currentBoard = new Board(filePathForBoard, lineCount);
        previousBoard = currentBoard;
        System.out.print("\nPrevious Board:");
        previousBoard.printBoard();
        lineCount = lineCount + previousBoard.getRowsOfBoard() + 1;
        currentBoard = new Board(filePathForBoard, lineCount);
        System.out.print("\nCurrent Board:");
        currentBoard.printBoard();
        System.out.print("\n NEW COMPARISON\n");

 */

    }
}
