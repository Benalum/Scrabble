/*
Creator: Alex Hartel
ArrayList of tiles that take tiles from boneyard or put tiles on board from hand
Created February 2024 for Scrabble assignment
 */


import java.util.ArrayList;


public class Hand {
    private ArrayList<Tile> hand;

    /*

    print hand

     */

    public void printHand(){
        for(Tile tile : hand){
            System.out.print(tile.toString() + " ");
        }
    }

    /*

    get size of hand

     */

    public int sizeOf(){
        return hand.size();
    }

    /*

    send boneyard to be utilized with Hand

     */

    public Hand(BoneYard boneYard) {
        initializeHand(boneYard);
    }

    /*

    Initialize

     */

    public Hand(){
        hand = new ArrayList<>();
    }

    /*

    create hand arraylist

     */

    private void initializeHand(BoneYard boneYard){
        hand = new ArrayList<>();
        //Logging.logInfo("Filling hand to 7 cards");
        checkHandIsFull(boneYard);
    }

    /*

    Checks to see if hand is full, if not place up to 7 tiles in it

     */

    private void checkHandIsFull(BoneYard boneYard){
        while(hand.size() < 7 && (!boneYard.isEmpty())){
            hand.add(boneYard.getTile());
        }
    }

    /*

    Add tile to hand

     */

    public void addTileToHand(Tile tile){
        hand.add(tile);
    }

    /*

    remove tile from hand

     */

    public void removeTileFromHand(Tile tile){
        hand.remove(tile);
    }

    /*

    remove tile at index

     */

    public void remove(int index){
        hand.remove(index);
    }

    /*

    get hand tile at index

     */

    public Tile getHandTile(int index){
        if(index >= 0 && index < hand.size()){
            return hand.get(index);
        } else {
            Logging.logError("hand index out of bounds: " + index);
            throw new IllegalArgumentException("Invalid index: " + index);
        }
    }
}
