import java.io.File;
import java.util.Set;

class LetterTree {
    private static LetterTreeNode root;

    public LetterTree(String[] words) {
        root = new LetterTreeNode(false);
        for (String word : words) {
            LetterTreeNode current = root;
            for (char letter : word.toCharArray()) {
                current.children.putIfAbsent(letter, new LetterTreeNode(false));
                current = current.children.get(letter);
            }
            current.isWord = true;
            //System.out.print("\nTRIE");
        }
    }


    public static LetterTreeNode getRoot() {
        return root;
    }

    public LetterTreeNode lookup(String word) {
        LetterTreeNode current = root;
        for (char letter : word.toCharArray()) {
            if (!current.children.containsKey(letter)) {
                //System.out.print("\n current child: " + current.children.get(letter));
                return null;
            }
            //System.out.print("\nChild: " + letter + " exists.");
            current = current.children.get(letter);
        }
        //System.out.print("\nshiz" + current.getChildren().toString());
        return current;
    }

    public boolean isWord(String word) {
        LetterTreeNode wordNode = lookup(word);
        return wordNode != null && wordNode.isWord;
    }

    public static LetterTree basicEnglish() {

        try {
            ReadInWords readInWords = new ReadInWords(new File("resources/sowpods.txt"));
            // Example usage of the dictionary
            Set<String> dictionary = readInWords.getDictionary();

            String[] temp = new String[dictionary.size()];


            int i = 0;
            for(String word : dictionary){
                temp[i++] = word;
            }
            //System.out.print(Arrays.toString(temp));
            // Perform operations with the dictionary here
            return new LetterTree(temp);
        } catch (RuntimeException e) {
            // Handle exception
        }
        return null;
    }
}
