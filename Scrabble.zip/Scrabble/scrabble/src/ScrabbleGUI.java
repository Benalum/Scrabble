import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ScrabbleGUI extends Application {
    private static final int SIZE = 15;
    private static final int TILE_SIZE = 40; // Tile size in pixels

    @Override
    public void start(Stage primaryStage) {
        GridPane grid = new GridPane();

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                Button tileButton = new Button();
                tileButton.setPrefSize(TILE_SIZE, TILE_SIZE);
                tileButton.setStyle("-fx-background-image: url('/path/to/image.png');"); // Replace with actual image path

                // Event handling for tile click
                int finalRow = row;
                int finalCol = col;
                tileButton.setOnAction(event -> handleTileClick(finalRow, finalCol));

                grid.add(tileButton, col, row);
            }
        }

        Scene scene = new Scene(grid);
        primaryStage.setTitle("Scrabble GUI");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleTileClick(int row, int col) {
        System.out.println("Tile clicked at: Row " + row + ", Col " + col);
        // Add logic for what happens when a tile is clicked
    }

    public static void main(String[] args) {
        launch(args);
    }
}
