/*
Creator: Alex Hartel
Has the class for the object Tile.
Created February 2024 for Scrabble assignment
Order finished
*/


import javax.swing.text.AttributeSet;
import java.lang.*;


public class Tile {
    private String first;
    private String second;

    /*

    return either the first or second number based on which one has a letter

     */

    public String getAlphabeticLetter(){
        try{
            if(isAlphabetic(first.charAt(0))){
                return first;
            }else if (isAlphabetic(second.charAt(0))){
                return second;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return "false";
    }

    /*

    return a string of either first or second based on which one has a number

     */

    public String getNumber(){
        try {
            if (isDigit(first.charAt(0))) {
                return first;
            } else if (isDigit(second.charAt(0))) {
                return second;
            }
        }catch(Exception e){
            throw new RuntimeException(e);
        }
        return "False";
    }

    /*

    boolean to see if it has a digit which will be used for a multiplier

     */


    public boolean hasDigit(){
        return (isDigit(first.charAt(0)) || isDigit(second.charAt(0)));
    }

    /*

    boolean to see if it has a letter

     */

    public boolean hasLetter(){

        return Character.isLetter(first.charAt(0)) || Character.isLetter(second.charAt(0));
    }



    /*

    Return a string  of the tile's first and second value

     */



    public String toString(){
        return "" + this.first + this.second;
    }

    /*

    Creation of tile that holds two strings if the input is a single string

     */

    public Tile(String temp) {
        this.first = temp.charAt(0) + "";
        this.second = temp.charAt(1) + "";
    }

    /*

    Create tile with character

     */

    public Tile(char c){
        this.first = c + "";
        this.second = " ";
    }

    /*

    Creation of a tile that holds two strings if given two strings

     */

    public Tile(String firstt, String secondd){
        this.first = firstt + "";
        this.second = secondd + "";
    }

    public void placeExactlySameTile(Tile tilea){
        first = tilea.first;
        second = tilea.second;
    }

    /*

    Place tile on board by finding the empty character and placing the letter there

     */

    public Tile tilePlacementOnBoard(Tile boardTile, Tile handTile){
        if (boardTile.isBlankIndex(first)){
            boardTile.first = handTile.getAlphabeticLetter();
        } else {
            boardTile.second = handTile.getAlphabeticLetter();
        }
        return boardTile;
    }

    /*

    search to see if tile on board has blank spot... Im thinking it might pay to only look for letters

     */

    private boolean isBlankIndex(String x){

        return (x.equals(".") || x.equals(","));
    }

    /*

    check if specific value is a digit

     */

    private boolean isDigit(char x){
        return Character.isDigit(x);
    }

    /*

    Check if specific character is a letter

     */

    private boolean isAlphabetic(char x){
        return Character.isAlphabetic(x);
    }

    /*

    get which index the value is in

     */


    public int getPositionOfNumber(){
        if(!Character.isDigit(first.charAt(0)) & !Character.isDigit(second.charAt(0))){
            return -1;
        }
        if(Character.isDigit(first.charAt(0))){
            return 0;
        }
        if(Character.isDigit(second.charAt(0))){
            return 1;
        }
        return -1;
    }

    public static void main(String[] Args){
        Tile x = new Tile(".", "3");
        Tile y = new Tile("3", ".");
        int z = x.getPositionOfNumber();
        int q = y.getPositionOfNumber();
        System.out.print("first: " + z + " Second: " + q);


        //replaceTileString();
    }

    /*

    Get the character that is used as the blank instead of hard coding a . or ,

     */
    public char getEmptyCharacterFromTile(){
        if (!hasDigit()){
            return first.charAt(0);
        } else if (Character.isDigit(first.charAt(0))) {
            return second.charAt(0);
        }else{
            return first.charAt(0);
        }
    }


}
