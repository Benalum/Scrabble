public class Trie {
    static final int ALPHSIZE = 26;
    private TrieNode root;


    public Trie(){
        root = new TrieNode(); //empty root
    }

    private class TrieNode{
        private TrieNode[] trieChildren;
        private boolean isEndOfWord;

        public TrieNode(){
            this.trieChildren = new TrieNode[ALPHSIZE];
            this.isEndOfWord = false;
        }
    }
    

    public boolean search(String word){
        int index;
        int lengOfWord = word.length();
        int level;
        TrieNode positionMove = root;

        for(level = 0; level < lengOfWord; level++){
            index = word.charAt(level) - 'a';  // 'a' otherwise out of bounds
            if(positionMove.trieChildren[index] == null){
                return false;
            }
            positionMove = positionMove.trieChildren[index];
        }
        return (positionMove.isEndOfWord);
    }

    public void insert(String key) {
        int lengOfWord = key.length();
        int level;
        int index;

        TrieNode positionMove = root;

        for(level = 0; level < lengOfWord; level++){
            index = key.charAt(level) - 'a';
            if(positionMove.trieChildren[index] == null){
                positionMove.trieChildren[index] = new TrieNode();
            }
            positionMove = positionMove.trieChildren[index];
        }
        // mark as last node
        positionMove.isEndOfWord = true;
    }

    public boolean lookUp(String word){
        int lengOfWord = word.length();
        int level;
        int index;

        TrieNode positionMove = root;

        for(level = 0; level < lengOfWord; level++){
            index = word.charAt(level) - 'a';
            if(positionMove.trieChildren[index] == null){
                return false;
            }
        }
        return true;
    }


    public static void main(String[] args){
        String[] words = {"hello", "itsme", "hi"};

        Trie root = new Trie();

        for (String word : words) {
            root.insert(word);
        }

        if(root.search("itsme")){
            System.out.print("\nYay");
        }
        if(!root.search("he")){
            System.out.print("\nNay");
        }


    }

}
