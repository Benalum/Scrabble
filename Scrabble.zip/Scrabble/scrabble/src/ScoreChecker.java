import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ScoreChecker {
    int lineCount = 0;
    static final File filePathForTileValues = new File("resources/scrabble_tiles.txt");
    static final File filePathForWords = new File("resources/sowpods.txt");
    Board currentBoard;
    Board previousBoard;
    int line = 0;
    ReadInWords dictionary;
    List<TileValues> tileValues;
    private String scoreSaver;
    boolean runFile = true;
    public ScoreChecker(File filePathForBoard) {
        dictionary = new ReadInWords(filePathForWords);
        tileValues = TileValues.readTileValues(filePathForTileValues);
        boolean first = true;
        try {

            while (runFile) {

                try {
                    if(first){
                        previousBoard = new Board(filePathForBoard, 0);
                        currentBoard = new Board(filePathForBoard, previousBoard.getLineOfDocument());
                        first = false;
                    }

                    else{
                        previousBoard = new Board(filePathForBoard, currentBoard.getLineOfDocument());
                        currentBoard = new Board(filePathForBoard, previousBoard.getLineOfDocument());
                    }

                    System.out.print("\noriginal board:");
                    previousBoard.printBoard();

                    System.out.print("\nresult board:");
                    currentBoard.printBoard();

                    // if legal
                    if (boardComparison(previousBoard, currentBoard)){
                        displayNewPlayDetails(previousBoard,currentBoard);
                        String[] wordAndScore = getWordPlayed(previousBoard).toString().split(" ");
                        System.out.print("\nplay is legal");
                        System.out.print("\n" + scoreSaver);
                    }

                    // not legal
                    else if (!getWordPlayed(previousBoard).isEmpty()){
                        displayNewPlayDetails(previousBoard,currentBoard);
                        System.out.print("\nplay is not legal");
                    }
                    System.out.print("\n");
                } catch (NullPointerException n) {
                    lineCount += 1;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.print("\nTry a different file");
            throw new RuntimeException(e);
        }
    }


    public boolean boardComparison(Board previousBoard, Board currentBoard){
        if (boardComparisonMatrixSize(previousBoard, currentBoard)) {
            // Check if matrix sizes are the same size
            if (bothBoardAreEmpty(previousBoard)) {
                System.out.print("\nplay is empty");
                System.out.print("\nplay is not legal");
            } else if (!previousBoard.getTileOnBoard(previousBoard.getRowsOfBoard() / 2,
                    previousBoard.getColsOfBoard() / 2).hasLetter() &
                    (!currentBoard.getTileOnBoard(currentBoard.getRowsOfBoard() / 2,
                            currentBoard.getColsOfBoard() / 2).hasLetter())) {
                //  Make sure center has letter on it if previous board is not empty
                return false;
            } else if (!previousBoardIsOnCurrentBoard(previousBoard)) {
                // Check to see if previous board has been tranferred to the new board
                System.out.print("\nIncompatible boards: tile removed at" + previousBoardIsOnCurrentBoardPosition(previousBoard));
                return false;
            } else if (previousBoardIsTheSameAsCurrentBoard(previousBoard)) {
                // check to see if boards are the same
                System.out.print("\nplay is empty");
                return false;
            }  else if (!previousBoard.getTileOnBoard(previousBoard.getRowsOfBoard() / 2,
                    previousBoard.getColsOfBoard() / 2).hasLetter() &
                    (!currentBoard.getTileOnBoard(currentBoard.getRowsOfBoard() / 2,
                            currentBoard.getColsOfBoard() / 2).hasLetter())) {
                // Extra check for center board haging latter
                return false;
            } else if (!boardMultipliersCheck(previousBoard)){
                System.out.print("\nIncompatible boards: multiplier mismatch at" + boardMultipliersCheckLocation(previousBoard));
                return false;
            } else if (!isWordPlacedNextToExistingWord(previousBoard) && !isPreviousBoardEmpty(previousBoard)){
                return false;
            }
            else {
                List<String> wordThenScoreList = getWordPlayed(previousBoard);
                for(String temp1 : wordThenScoreList){
                    String[] wordThenScore = temp1.split(" ");

                    int score = (Integer.parseInt(wordThenScore[1]) * Integer.parseInt(wordThenScore[2]));

                    List<String> surroundingWords = getWordsAroundWordPlayed(Integer.parseInt(wordThenScore[3]), Integer.parseInt(wordThenScore[4]), previousBoard, directionOfWord(previousBoard, currentBoard));

                    boolean isInDic = true;
                    for(String word : surroundingWords){
                        //System.out.print("\nword: " + word);
                        String[] temp = word.replace("[","").replace("]","").split(", ");
                        for( int i = 0; i < temp.length; i++){
                            String[] newTemp = temp[i].split(" ");
                            if(!this.dictionary.contains(newTemp[0].replace("[","").replace("]",""))){
                                isInDic = false;
                                score = 0;
                                //System.out.print("\n" + newTemp[0] + " is not in the dic");
                                break;
                            }else {
                                //System.out.print("\n" + Arrays.toString(temp));
                                score += Integer.parseInt(newTemp[1].replace("[", "").replace("]", "").replace(",", ""));
                                //System.out.print("\nAdd to score: " + Integer.parseInt(newTemp[1].replace("[", "").replace("]", "").replace(",", "")));
                            }
                        }
                    }
                    scoreSaver = "Score: " + score;
                    return isInDic;
                }
            }
        }else{
            System.out.print("Invalid: Board Sizes are different.");
            return false;
        }
        return false;
    }

    private boolean isPreviousBoardEmpty(Board previousBoard){
        for (int i = 0; i < previousBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasLetter()){
                    return false;
                }
            }
        }
        return true;
    }

    private boolean boardMultipliersCheck(Board previousBoard){
        for (int i = 0; i < previousBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasDigit()){
                    if(!currentBoard.getTileOnBoard(i,j).hasDigit() && !currentBoard.getTileOnBoard(i,j).hasLetter()){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private String boardMultipliersCheckLocation(Board previousBoard){
        for (int i = 0; i < previousBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasDigit()){
                    if(!currentBoard.getTileOnBoard(i,j).hasDigit() && !currentBoard.getTileOnBoard(i,j).hasLetter()){
                        return " (" +  i + ", " + j + ")";
                    }
                }
            }
        }
        return "";
    }


    private boolean boardComparisonMatrixSize(Board one, Board two){
        return ((one.getRowsOfBoard() == two.getRowsOfBoard()) && (one.getColsOfBoard() == two.getColsOfBoard()));
    }


    private List<String[]> getNewWordPositions(Board previousBoard, Board currentBoard) {
        List<String[]> newTileDetails = new ArrayList<>();
        for (int i = 0; i < currentBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < currentBoard.getColsOfBoard(); j++) {
                if (currentBoard.getTileOnBoard(i, j).hasLetter() && !previousBoard.getTileOnBoard(i, j).hasLetter()) {
                    String letter = currentBoard.getTileOnBoard(i, j).getAlphabeticLetter() + "";
                    newTileDetails.add(new String[]{String.valueOf(i), String.valueOf(j), letter});
                }
            }
        }
        return newTileDetails;
    }

    private String directionOfWord(Board previousBoard, Board currentBoard) {
        int previousRow = 0;
        int previousCol = 0;
        String direction = null;
        boolean firstCheckComplete = false;
        List<String[]> newTileDetails = getNewWordPositions(previousBoard, currentBoard);
        for (int i = 0; i < newTileDetails.size(); i++) {
            //System.out.print("\nPrevRow: " + previousRow + " Prev Col: " + previousCol);
            String[] tileDetail = newTileDetails.get(i);
            int row = Integer.parseInt(tileDetail[0]);
            int column = Integer.parseInt(tileDetail[1]);
            if (!firstCheckComplete){
                previousRow = row;
                previousCol = column;
                firstCheckComplete = true;
            }else{
                if(previousRow != row){
                    direction = "ns";
                    return direction;
                }else{
                    direction = "we";
                    return direction;
                }
            }
        }
        return direction;
    }


    private void displayNewPlayDetails(Board previousBoard, Board currentBoard) {
        List<String[]> newTileDetails = getNewWordPositions(previousBoard, currentBoard);
        StringBuilder playDetails = new StringBuilder("play is ");
        for (int i = 0; i < newTileDetails.size(); i++) {
            String[] tileDetail = newTileDetails.get(i);
            String letter = tileDetail[2];
            int row = Integer.parseInt(tileDetail[0]);
            int column = Integer.parseInt(tileDetail[1]);

            playDetails.append(letter).append(" at (").append(row).append(", ").append(column).append(")");
            if (i < newTileDetails.size() - 1) {
                playDetails.append(", ");
            }
        }
        System.out.print("\n" + playDetails.toString());
    }


    private boolean previousBoardIsOnCurrentBoard(Board previousBoard){
        boolean whatToReturn = true;
        String word = "";
        for(int i = 0; i < previousBoard.getRowsOfBoard(); i++){
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasLetter()){
                    if(!Objects.equals(previousBoard.getTileOnBoard(i, j).getAlphabeticLetter(),
                            currentBoard.getTileOnBoard(i, j).getAlphabeticLetter())) {
                        String temp = (i + ", " + j);
                        whatToReturn = false;
                    }
                }
            }
        }
        return whatToReturn;
    }

    private String previousBoardIsOnCurrentBoardPosition(Board previousBoard){
        boolean whatToReturn = true;
        String temp = "";
        for(int i = 0; i < previousBoard.getRowsOfBoard(); i++){
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasLetter()){
                    if(!Objects.equals(previousBoard.getTileOnBoard(i, j).getAlphabeticLetter(),
                            currentBoard.getTileOnBoard(i, j).getAlphabeticLetter())) {
                        return " (" + i + ", " + j + ")";
                    }
                }
            }
        }
        return temp;
    }


    private boolean bothBoardAreEmpty(Board previousBoard){
        for(int i = 0; i < previousBoard.getRowsOfBoard(); i++){
            for (int j = 0; j < previousBoard.getColsOfBoard();j ++){
                if(previousBoard.getTileOnBoard(i,j).hasLetter() || currentBoard.getTileOnBoard(i,j).hasLetter()){
                    return false;
                }
            }
        }
        return true;
    }


    private boolean previousBoardIsTheSameAsCurrentBoard(Board previousBoard){
        for(int i = 0; i < previousBoard.getRowsOfBoard(); i++){
            for (int j = 0; j < previousBoard.getColsOfBoard(); j++) {
                if(previousBoard.getTileOnBoard(i,j).hasLetter() & !currentBoard.getTileOnBoard(i,j).hasLetter() ){
                    return true;
                }
                else if(previousBoard.getTileOnBoard(i,j).hasLetter() & currentBoard.getTileOnBoard(i,j).hasLetter()){
                    if(!Objects.equals(previousBoard.getTileOnBoard(i,j).getAlphabeticLetter().toLowerCase(Locale.ROOT)
                            , currentBoard.getTileOnBoard(i,j).getAlphabeticLetter().toLowerCase())){
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private boolean isWordPlacedNextToExistingWord(Board previousBoard) {
        boolean returnValue = false;
        for (int i = 0; i < currentBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < currentBoard.getColsOfBoard(); j++) {
                if (currentBoard.getTileOnBoard(i, j).hasLetter() & !previousBoard.getTileOnBoard(i,j).hasLetter()) {
                    // Check top, bottom, left, right tiles if they are within the board bounds
                    if ((i > 0 && previousBoard.getTileOnBoard(i - 1, j).hasLetter()) || // Top
                            (i < currentBoard.getRowsOfBoard() - 1
                                    && previousBoard.getTileOnBoard(i + 1, j).hasLetter()) || // Bottom
                            (j > 0 && previousBoard.getTileOnBoard(i, j - 1).hasLetter()) || // Left
                            (j < currentBoard.getColsOfBoard() - 1
                                    && previousBoard.getTileOnBoard(i, j + 1).hasLetter())) { // Right
                            returnValue = true;
                    }
                }
            }
        }
        return returnValue;
    }


    private int getScoreFromLetter(List<TileValues> tileValues, char letter) {
        for (TileValues tiles : tileValues) {
            if(Character.toLowerCase(letter) == tiles.getLetter()){
                return tiles.getValue();
            }
        }
        return 0; // return 0 for blank or non-existing tiles
    }


    private List<String> getWordPlayed(Board previousBoard){
        List<String> verticalAndHorizontalWords = new ArrayList<>();
        boolean getStart = true;
        int startCol = 0;
        int endCol;
        int startRow = 0;
        int endRow;
        for (int i = 0; i < currentBoard.getRowsOfBoard(); i++) {
            for (int j = 0; j < currentBoard.getColsOfBoard(); j++) {

                Tile currentTile = currentBoard.getTileOnBoard(i, j);
                Tile previousTile = previousBoard.getTileOnBoard(i, j);

                // Check if there's a new letter placed at this position
                if (currentTile.hasLetter() && (previousTile == null || !previousTile.hasLetter())) {
                    if(getStart){
                        startRow = i;
                        startCol = j;
                        getStart = false;
                    }

                    // Check horizontally and vertically for words
                    String horizontalWord = checkHorizontalWord(i, j, currentBoard);
                    String verticalWord = checkVerticalWord(i, j, currentBoard);
                    //System.out.print("Direction: " + directionOfWord(previousBoard,currentBoard));
                    // Return the word that includes the new letter
                    if (horizontalWord.length() > 1) {
                        verticalAndHorizontalWords.add(horizontalWord.toLowerCase());
                        //System.out.print("\nHorizontal Word played: " + horizontalWord);
                        //return horizontalWord.toLowerCase();

                    } if (verticalWord.length() > 1) {
                        verticalAndHorizontalWords.add(verticalWord);
                        //System.out.print("\nVertical Word played: " + verticalWord);
                        //return verticalWord.toLowerCase();
                    }
                }
            }
        }
        return verticalAndHorizontalWords;
    }

    private List<String> getWordsAroundWordPlayed(int row, int col, Board previousBoard, String direction){
        //System.out.print("\nrow: " + row + " col: " + col + " direction: " + direction);
        List<String> attachedWords = new ArrayList<>();

        if(direction.equals("ns")){
            // word is vertical check horizontally attached words
            // Check horizontally and vertically for words
            //System.out.print("\nDirection is ns " + row + " " + col);

            List<String> horizontalWordOneWay = checkHorizontalWordsAttachedToPlayedWord(row, col, currentBoard, previousBoard);
            //System.out.print("\nWord surrounding Horizontal: " + horizontalWordOneWay.toString());
            if (!horizontalWordOneWay.isEmpty()) {
                attachedWords.add(horizontalWordOneWay.toString());
                //System.out.print("\nWord surrounding Horizontal: " + horizontalWordOneWay);
            }


        }
        if(direction.equals("we")){
            // Word is horizontal, check for vertical word attachments
            List<String> verticalWordOneWay = checkVerticalWordsAttachedToPlayedWord(row, col, currentBoard, previousBoard);
            if (!verticalWordOneWay.isEmpty()) {
                attachedWords.add(verticalWordOneWay.toString());
                //System.out.print("\nWord surrounding Vertical: " + verticalWordOneWay);
            }
        }
        return attachedWords;
    }

    private List<String> checkVerticalWordsAttachedToPlayedWord(int startRow, int col, Board board, Board previousBoard) {
        List<String> holder = new ArrayList<>();
        StringBuilder word = new StringBuilder();
        int wordScore = 0; // Initialize the word score
        int wordMultiplier = 1;

        // Move up
        int startRowHolder = startRow;

        while(col >= 0 && col < board.getColsOfBoard() && board.getTileOnBoard(startRowHolder, col).hasLetter()) {
            //System.out.print("\nUp: " + startRowHolder + " Col: " + col);
            if (board.getTileOnBoard(startRowHolder, col).hasLetter() && !previousBoard.getTileOnBoard(startRowHolder, col).hasLetter()) {

                while (startRowHolder >= 0) {
                    if (board.getTileOnBoard(startRowHolder, col).hasLetter()) {
                        startRowHolder--;
                    } else {
                        break;
                    }
                }

                int up = startRowHolder + 1;

                //System.out.print("\nINSIDE: " + up + " " + col);

                while (up < board.getRowsOfBoard() && up >= 0 && board.getTileOnBoard(up, col).hasLetter()) {
                    if (startRow - 1 > 0 && startRow + 1 > board.getRowsOfBoard()) {
                        if ((board.getTileOnBoard(startRow - 1, col).hasLetter() & board.getTileOnBoard(startRow + 1, col).hasLetter())
                                || (!board.getTileOnBoard(startRow - 1, col).hasLetter() & !board.getTileOnBoard(startRow + 1, col).hasLetter())) {
                            //System.out.print("\nNo tiles to use");
                            break;
                        }
                    }

                    //System.out.print("\nLetter: " + board.getTileOnBoard(up, col).getAlphabeticLetter());
                    word.append(board.getTileOnBoard(up, col).getAlphabeticLetter());
                    wordScore += getScoreFromLetter(tileValues, board.getTileOnBoard(up, col).getAlphabeticLetter().charAt(0));
                    if (previousBoard.getTileOnBoard(up, col).hasDigit()) {
                        wordMultiplier *= Integer.parseInt(previousBoard.getTileOnBoard(up, col).getNumber());
                    }
                    up++;
                }
                //System.out.print("\nWord: " + word.toString() + wordScore + wordMiltiplier);
                if (word.length() > 1) {
                    int newScore = wordScore * wordMultiplier;
                    // Return the word and its score
                    holder.add(word.toString() + " " + newScore);
                    word = new StringBuilder("");
                    wordScore = 0;
                    wordMultiplier = 1;
                } else {
                    word = new StringBuilder("");
                    wordScore = 0;
                    wordMultiplier = 1;
                }
                //System.out.print("\nnew" + holder.toString());
                // reset everything
                startRowHolder = startRow;
                col++;
            }
            else{
                col++;
            }
        }
        return holder;
    }


    private List<String> checkHorizontalWordsAttachedToPlayedWord(int row, int startCol, Board board, Board previousBoard) {
        List<String> holder = new ArrayList<>();
        StringBuilder word = new StringBuilder();
        int wordScore = 0;
        int wordMiltiplier = 1;

        // move all the way left to check word
        int startCallHolder = startCol;


        while (board.getTileOnBoard(row, startCallHolder).hasLetter() && row >= 0 && row < board.getRowsOfBoard()) {
            //System.out.print("\nRow: " + row + " Col: " + startCallHolder);
            if (board.getTileOnBoard(row, startCallHolder).hasLetter() && !previousBoard.getTileOnBoard(row, startCallHolder).hasLetter()){
                while (startCallHolder >= 0) {
                    //System.out.print("\n" + startCallHolder);
                    if (board.getTileOnBoard(row, startCallHolder).hasLetter()) {
                        startCallHolder--;
                    } else {
                        break;
                    }
                }

                int right = startCallHolder + 1;

                //System.out.print("\nINSIDE " + row  + " " + right);

                while (right < board.getColsOfBoard() && board.getTileOnBoard(row, right).hasLetter() && right >= 0) {
                    // If letter is on both sides or neither side has tile break
                    if (startCol - 1 > 0 && startCol + 1 > board.getColsOfBoard()) {
                        if ((board.getTileOnBoard(row, startCol - 1).hasLetter() & board.getTileOnBoard(row, startCol + 1).hasLetter())
                                || (!board.getTileOnBoard(row, startCol - 1).hasLetter() & !board.getTileOnBoard(row, startCol + 1).hasLetter())) {
                            //System.out.print("\nNo tiles to use");
                            break;
                        }
                    }

                    //System.out.print("\nLetter: " + board.getTileOnBoard(row, right).getAlphabeticLetter());
                    word.append(board.getTileOnBoard(row, right).getAlphabeticLetter());
                    wordScore += getScoreFromLetter(tileValues, board.getTileOnBoard(row, right).getAlphabeticLetter().charAt(0));
                    if (previousBoard.getTileOnBoard(row, right).hasDigit()) {
                        wordMiltiplier *= Integer.parseInt(previousBoard.getTileOnBoard(row, right).getNumber());
                    }
                    right++;
                }
                //System.out.print("\nWord: " + word.toString() + wordScore + wordMiltiplier);
                if (word.length() > 1) {
                    int newScore = wordScore * wordMiltiplier;
                    // Return the word and its score
                    holder.add(word.toString() + " " + newScore);
                    word = new StringBuilder("");
                    wordScore = 0;
                    wordMiltiplier = 1;
                } else {
                    word = new StringBuilder("");
                    wordScore = 0;
                    wordMiltiplier = 1;
                }
                //System.out.print("\nnew" + holder.toString());
                // reset everything
                startCallHolder = startCol;
                row++;
            }
            else{
                row++;
            }
        }
        return holder;

    }

    public static void main(String[] args){
        final File filePathForBoard = new File("resources/example_score_input.txt");
        new ScoreChecker(filePathForBoard);
    }

    private String checkVerticalWord(int startRow, int col, Board board) {
        StringBuilder word = new StringBuilder();
        int wordScore = 0; // Initialize the word score
        int wordScoreMultiplier = 1;
        int startRowForWord;
        int startColForWord;
        int endRowForWord;
        int endColForWord;

        // Move up
        int startRowTemp = startRow;

        while (startRowTemp >= 0 && startRowTemp < board.getRowsOfBoard() && board.getTileOnBoard(startRowTemp, col).hasLetter()) {
            if(board.getTileOnBoard(startRowTemp, col).hasLetter()){
                //System.out.print("\n" + board.getTileOnBoard(startRowTemp, col).getAlphabeticLetter() + startRowTemp);
                startRowTemp++;
            }else{
                break;
            }
            //System.out.print("\nStartRowTemp: " + startRowTemp);
        }

        int down = startRowTemp - 1;

        // Set initial row col
        startColForWord = col;
        startRowForWord = down + 1;
        endColForWord = col;
        endRowForWord = down;

        //System.out.print("\nStart off at: " + down);
        while (down >= 0 && down < board.getRowsOfBoard() && board.getTileOnBoard(down, col).hasLetter()) {
            word.insert(0, board.getTileOnBoard(down, col).getAlphabeticLetter());
            if(previousBoard.getTileOnBoard(down,col).hasDigit()) {
                if(previousBoard.getTileOnBoard(down,col).getPositionOfNumber() == 0){
                    // left is word multiplier
                    wordScoreMultiplier *= Integer.parseInt(previousBoard.getTileOnBoard(down,col).getNumber());
                    wordScore += getScoreFromLetter(tileValues, board.getTileOnBoard(down, col).getAlphabeticLetter().charAt(0));
                }
                else if(previousBoard.getTileOnBoard(down, col).getPositionOfNumber() == 1){
                    // right is letter multiplier
                    wordScore += Integer.parseInt(previousBoard.getTileOnBoard(down, col).getNumber()) *
                            getScoreFromLetter(tileValues, board.getTileOnBoard(down, col).getAlphabeticLetter().charAt(0));
                }
            }else{
                // no multiplier
                if(currentBoard.getTileOnBoard(down, col).hasLetter()) {
                    //System.out.print(row + right + " " + previousBoard.getTileOnBoard(row, right).getNumber());
                    wordScore +=  getScoreFromLetter(tileValues, board.getTileOnBoard(down, col).getAlphabeticLetter().charAt(0));
                }
            }
            startRowForWord--;
            down--;
        }
        // Return the word and its score
        if(word.length() > 1) {
            if(wordScoreMultiplier == 0){
                wordScoreMultiplier = 1;
            }
            //System.out.print("\nVertical: " + word.toString() + " " + wordScore + " " + wordScoreMultiplier);
            return word.toString() + " " + wordScore + " " + wordScoreMultiplier + " " + startRowForWord + " " + startColForWord + " " + endRowForWord + " " + endColForWord;
        }else{
            return "";
        }
    }


    private String checkHorizontalWord(int row, int startCol, Board board) {
        int startColForWord;
        int startRowForWord;
        int endColForWord;
        int endRowForWord;

        StringBuilder word = new StringBuilder();

        int wordScore = 0;
        int wordScoreMultiplier = 1;

        //Check left, then right to get whole word
        int startColTemp = startCol;

        while (startColTemp < board.getRowsOfBoard() && startColTemp >= 0 && board.getTileOnBoard(row, startColTemp).hasLetter()) {
            if(board.getTileOnBoard(row,startColTemp).hasLetter()) {
                startColTemp--;
            }else{
                break;
            }
        }
        int right = startColTemp + 1;

        // Set columns
        startColForWord = right;
        startRowForWord = row;
        endRowForWord = row;
        endColForWord = right - 1;


        while ( right >= 0 && right < board.getColsOfBoard() && board.getTileOnBoard(row, right).hasLetter()) {
            word.append(board.getTileOnBoard(row, right).getAlphabeticLetter());
            if(previousBoard.getTileOnBoard(row,right).hasDigit()) {
                if(previousBoard.getTileOnBoard(row,right).getPositionOfNumber() == 0){
                    // left is word multiplier
                    wordScoreMultiplier *= Integer.parseInt(previousBoard.getTileOnBoard(row,right).getNumber());
                    wordScore += getScoreFromLetter(tileValues, board.getTileOnBoard(row, right).getAlphabeticLetter().charAt(0));
                }
                else if(previousBoard.getTileOnBoard(row, right).getPositionOfNumber() == 1){
                    // right is letter multiplier
                    wordScore += Integer.parseInt(previousBoard.getTileOnBoard(row, right).getNumber()) *
                            getScoreFromLetter(tileValues, board.getTileOnBoard(row, right).getAlphabeticLetter().charAt(0));
                }
            }else{
                // no multiplier
                if(currentBoard.getTileOnBoard(row, right).hasLetter()) {
                    wordScore +=  getScoreFromLetter(tileValues, board.getTileOnBoard(row, right).getAlphabeticLetter().charAt(0));
                }
            }
            endColForWord ++;
            right++;
        }

        // Return the word and its score
        if(word.length() > 1) {
            if(wordScoreMultiplier == 0){
                wordScoreMultiplier = 1;
            }
            //System.out.print("\nVertical: " + word.toString() + " " + wordScore + " " + wordScoreMultiplier);
            return word.toString() + " " + wordScore + " " + wordScoreMultiplier + " " + startRowForWord + " " + startColForWord + " " + endRowForWord + " " + endColForWord;
        }else{
            return "";
        }
    }


}
