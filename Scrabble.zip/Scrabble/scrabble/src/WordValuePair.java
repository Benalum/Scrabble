class WordValuePair {
    private String word;
    private int value;

    public WordValuePair(String word, int value) {
        this.word = word;
        this.value = value;
    }

    public String getWord() {
        return word;
    }

    public int getValue() {
        return value;
    }
}