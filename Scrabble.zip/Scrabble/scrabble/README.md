Human player goes first all the time.
